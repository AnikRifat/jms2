<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Destination;

class DestinationSeeder extends Seeder
{
    public function run()
    {
        // Create some sample destinations
        $destinations = [
            [
                'title' => 'Dubai',
                'description' => 'We offer a range of Hajj packages to meet your needs and budget.',
                'image' => '3.jpg',
                 'status' => 1,
                'ranking' => 1,
            ],
            [
                'title' => 'Arab',
                'description' => 'Experience the beauty and spirituality of Umrah with our affordable packages.',
                'image' => '2.jpg',
                 'status' => 1,
                'ranking' => 2,
            ],
            [
                'title' => 'Mishor',
                'description' => 'Visit the holy sites of Islam with our expertly curated Ziyarat packages.',
                'image' => '1.jpg',
                 'status' => 0,
                'ranking' => 3,
            ],
        ];

        // Insert the destinations into the database
        Destination::insert($destinations);
    }
}
