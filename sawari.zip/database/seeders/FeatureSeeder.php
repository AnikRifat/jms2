<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Feature;

class FeatureSeeder extends Seeder
{
    public function run()
    {
        // Create some sample features
        $features = [
            [
                'title' => 'Travel Arrangements',
                'description' => 'Lorem ipsum dolor sit ametpr consect adiu piscing eli sed diam nonum euismo.',
                'image' => '1.png',
                'ranking' => 1,
            ],
            [
                'title' => 'Best Price Guarantee',
                'description' => 'Lorem ipsum dolor sit ametpr consect adiu piscing eli sed diam nonum euismo.',
                'image' => '2.png',
                'ranking' => 2,
            ],
            [
                'title' => 'BHappy Clients',
                'description' => 'Lorem ipsum dolor sit ametpr consect adiu piscing eli sed diam nonum euismo.',
                'image' => '3.png',
                'ranking' => 3,
            ],
            [
                'title' => 'Travel Insurance',
                'description' => 'Lorem ipsum dolor sit ametpr consect adiu piscing eli sed diam nonum euismo.',
                'image' => '4.png',
                'ranking' => 4,
            ],
        ];

        // Insert the features into the database
        Feature::insert($features);
    }
}
