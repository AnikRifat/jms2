<?php

namespace Database\Seeders;

use App\Models\Service;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {

        $this->call([
            UserSeeder::class,
            PackageSeeder::class,
            HeroSeeder::class,
            ServiceSeeder::class,
            ContentSeeder::class,
            BlogSeeder::class,
            DestinationSeeder::class,
            TestimonialSeeder::class,
            PhotoSeeder::class,
            FeatureSeeder::class,
        ]);
    }
}
