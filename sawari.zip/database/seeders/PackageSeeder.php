<?php
namespace Database\Seeders;

use App\Models\Package;
use Illuminate\Database\Seeder;
use Faker\Factory as Faker;

class PackageSeeder extends Seeder
{
    public function run()
    {
        // Create Faker instance
        $faker = Faker::create();
        $strings = ["Dubai", "Arab", "Mishor"];
        $randomIndex = array_rand($strings);
        // Generate 10 hajj packages
        for ($i = 0; $i < 10; $i++) {
            $package = new Package([
                'title' => $faker->sentence(4) . ' Hajj Package',
                'subtitle' => $faker->sentence(6),
                'description' => $faker->paragraphs(3, true),
                'itinerary' => $faker->paragraphs(5, true),
                'notes_policy' => $faker->paragraphs(2, true),
                'packages_pricing' => $faker->paragraphs(2, true),
                'price' => $faker->randomFloat(2, 5000, 15000),
                'destination_id' => $faker->numberBetween(1, 3),
                'duration' => '21 Days',
                'check_in' => $faker->dateTimeBetween('next year + 8 months', 'next year + 9 months'),
                'check_out' => $faker->dateTimeBetween('next year + 9 months + 1 day', 'next year + 10 months'),
                'tour_map' => 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d237684.5487548047!2d39.706462292845366!3d21.43627673722652!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c204b74d3fb493%3A0x55d1f94f8e094785!2sMasjid%20al-Haram!5e0!3m2!1sen!2sbd!4v1681031133322!5m2!1sen!2sbd',
                'image' => 'img ('.$i.').jpg',
                'service_id' => $faker->numberBetween(1, 3),
                'ranking' => $i,
                'status' => 1,
            ]);
            $package->save();
        }
    }
}
