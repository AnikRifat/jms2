<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TestimonialSeeder extends Seeder{

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('testimonials')->insert([
            [
                'title' => 'MD Atique',
                'subtitle' => 'Ziyaatt Travellers',
                'description' => 'Experience the beauty and spirituality of Umrah with our affordable packages.',
                'image' => 'dummy.jpg',
            ],
            [
                'title' => 'MD Rifat',
                'subtitle' => 'Umrah Travellers',
                'description' => 'Experience the beauty and spirituality of Umrah with our affordable packages.',
                'image' => 'dummy.jpg',
            ],
            [
                'title' => 'MD Jamal',
                'subtitle' => 'Hajj Travellers',
                'description' => 'Experience the beauty and spirituality of Umrah with our affordable packages.',
                'image' => 'dummy.jpg',
            ],
        ]);

    }
}
