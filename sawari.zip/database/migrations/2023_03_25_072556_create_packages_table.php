<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePackagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('packages', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('subtitle');
            $table->longText('description');
            $table->longText('itinerary');
            $table->longText('notes_policy');
            $table->longText('packages_pricing');
            $table->decimal('price', 8, 2);
            $table->string('destination_id')->nullable();
            $table->string('duration');
            $table->date('check_in');
            $table->date('check_out');
            $table->text('tour_map');
            $table->string('image');
            $table->string('service_id');
            $table->tinyInteger('ranking');
            $table->tinyInteger('status')->default('1');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('packages');
    }
}
