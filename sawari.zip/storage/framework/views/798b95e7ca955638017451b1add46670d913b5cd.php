



<!-- testimonial area start here -->
<section class="section-paddings testimonial-two">
    <div class="testimonial-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title text-center">
                        <h2>Happy travellers</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum
                            sodales Sed luctus orci vel nibh aliquam laoreet Aenean accumsan .</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <!-- start top media -->
                    <div class="top-testimonial-image row slick-pagination">
                        <div class="carousel-images slider-nav-two col-sm-8 col-sm-offset-2">
                            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <span><img src="<?php echo e(asset('uploads/testimonials/' . $testimonial->image)); ?>" alt="1"
                                            class="img-responsive img-circle"></span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>
                    </div><!-- end top media images -->

                    <!-- bottom testimonial message -->
                    <div class="block-text row">
                        <div class="carousel-text slider-for-two col-sm-8 col-sm-offset-2">
                            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="single-box">
                                    <p><?php echo e($testimonial->description); ?>

                                    </p>
                                    <div class="client-bio">
                                        <h3><?php echo e($testimonial->title); ?></h3>
                                        <span><?php echo e($testimonial->subtitle); ?></span>
                                    </div>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>
                    </div><!-- bottom testimonial message -->
                </div><!-- /.block-text -->
            </div>
        </div>
    </div>
</section><!-- testimonial area end here -->
<?php /**PATH C:\xampp\htdocs\sawari\resources\views/web/component/testimonial.blade.php ENDPATH**/ ?>