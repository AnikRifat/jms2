
    <meta charset="UTF-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="TRABBLE - Tour, Travel, Travel Agency Template">
    <meta name="keywords" content="Tour, Travel, Travel Agency Template">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sawari - Tour, Travel & Travel Agency Template</title>


<?php /**PATH C:\xampp-8-1\htdocs\sawari\resources\views/web/inc/head.blade.php ENDPATH**/ ?>