

<section class="section-paddings">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="section-title-version-2-black text-center">
                    <h2>Gallery from Travelars</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum </p>
                </div>
            </div>
        </div>
        <div class="container">

            <div class="gridbox">
                <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div><img src="<?php echo e(asset('uploads/photos/' . $photo->image)); ?>" alt=""></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>


        </div>
        <!-- gallery iteam start here -->
        
    </div>
</section> <!-- gallery section end here -->
<?php /**PATH C:\xampp\htdocs\sawari\resources\views/web/component/gallery.blade.php ENDPATH**/ ?>