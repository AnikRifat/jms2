<section class="section-paddings welcome-area">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="single-welcome-area">
                    <div class="single-imag">
                        <img src="<?php echo e(asset('uploads/content/' . $content->about_image)); ?>" alt="" class="img-thumbnail img-responsive">
                    </div>

                </div>
            </div> <!-- welcome area left side end -->

            <div class="col-md-6">
                <div class="single-welcome-text">
                    <div class="section-title-version-2">
                        <h2><?php echo e($content->about_title); ?></h2>
                        <h5><?php echo e($content->about_subtitle); ?></h5>
                        <div class="welcome-content">
                            <p>
                                <?php echo $content->about_content; ?>

                            </p>
                            <a href="#" class="read-more hvr-fade">Read More</a>
                        </div>
                    </div>
                </div>
            </div>  <!-- welcome area right side end -->
        </div>
    </div>
</section>
<?php /**PATH /home8/thesawari/public_html/resources/views/web/component/about.blade.php ENDPATH**/ ?>