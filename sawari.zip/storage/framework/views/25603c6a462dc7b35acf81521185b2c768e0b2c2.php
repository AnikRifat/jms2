




<section class="section-blog-bg blog-2">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-xs-12">
                <div class="section-title-version-2-white text-center">
                    <h2>Travel guide and Expert Advice</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum </p>
                </div>
            </div>
        </div>
        <div class="row">

            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <!-- single travel blog-->
            <div class="col-md-4 col-sm-6 single-item">
                <div class="single-travel-blog single-travel-blog-2">
                    <div class="blog-image">
                        <a href="<?php echo e(route('blog.details', $blog->title)); ?>"><img src="<?php echo e(asset('uploads/blogs/' . $blog->image)); ?>" alt="">
                        </a>
                    </div>
                    <div class="blog-content">
                        <div class="blog-post-content">
                            <h4><?php echo e($blog->title); ?></h4>
                            <div class="blog-meta">
                                <ul class="post-social-2">
                                    <li><a href="<?php echo e(route('blog.details', $blog->title)); ?>"><i class="fa fa-calendar"></i>  <?php echo e(\Carbon\Carbon::parse($blog->created_at)->format('d M, Y')); ?></a>
                                    </li>

                                </ul>
                            </div>
                            <p><?php echo e($blog->subtitle); ?></p>
                        </div>
                        <div class="read-more-btn">
                            <a href="<?php echo e(route('blog.details', $blog->title)); ?>">Read More <i class="fa fa-angle-right"> </i></a>
                        </div>

                    </div>
                </div>
            </div>
            <!-- single travel guide & security end-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</section>
<?php /**PATH C:\xampp\htdocs\sawari\resources\views/web/component/blog.blade.php ENDPATH**/ ?>