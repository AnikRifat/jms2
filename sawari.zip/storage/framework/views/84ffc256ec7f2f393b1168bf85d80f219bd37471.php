        <!-- JAVASCRIPT -->
        <script src="<?php echo e(asset('')); ?>assets/admin/libs/jquery/jquery.min.js"></script>
        <script src="<?php echo e(asset('')); ?>assets/admin/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="<?php echo e(asset('')); ?>assets/admin/libs/metismenu/metisMenu.min.js"></script>
        <script src="<?php echo e(asset('')); ?>assets/admin/libs/simplebar/simplebar.min.js"></script>
        <script src="<?php echo e(asset('')); ?>assets/admin/libs/node-waves/waves.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/js/dropify.js" integrity="sha512-hJsxoiLoVRkwHNvA5alz/GVA+eWtVxdQ48iy4sFRQLpDrBPn6BFZeUcW4R4kU+Rj2ljM9wHwekwVtsb0RY/46Q==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <!-- apexcharts -->
        <script src="<?php echo e(asset('')); ?>assets/admin/libs/apexcharts/apexcharts.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
        <!-- dashboard init -->
        <script src="<?php echo e(asset('')); ?>assets/admin/js/pages/dashboard.init.js"></script>
        <script src="<?php echo e(asset('')); ?>assets/admin/libs/tinymce/tinymce.min.js"></script>
        <!-- Required datatable js -->
        <script src="<?php echo e(asset('')); ?>assets/admin/libs/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo e(asset('')); ?>assets/admin/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
                <!-- Buttons examples -->
                <script src="<?php echo e(asset('')); ?>assets/admin/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
                <script src="<?php echo e(asset('')); ?>assets/admin/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
                <script src="<?php echo e(asset('')); ?>assets/admin/libs/jszip/jszip.min.js"></script>
                <script src="<?php echo e(asset('')); ?>assets/admin/libs/pdfmake/build/pdfmake.min.js"></script>
                <script src="<?php echo e(asset('')); ?>assets/admin/libs/pdfmake/build/vfs_fonts.js"></script>
                <script src="<?php echo e(asset('')); ?>assets/admin/libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
                <script src="<?php echo e(asset('')); ?>assets/admin/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
                <script src="<?php echo e(asset('')); ?>assets/admin/libs/datatables.net-buttons/js/buttons.colVis.min.js"></script>

        <!-- Responsive examples -->
        <script src="<?php echo e(asset('')); ?>assets/admin/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
        <script src="<?php echo e(asset('')); ?>assets/admin/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>

                <script src="<?php echo e(asset('')); ?>assets/admin/js/pages/datatables.init.js"></script>

        <!-- Sweet Alerts js -->
        <script src="<?php echo e(asset('')); ?>assets/admin/libs/sweetalert2/sweetalert2.min.js"></script>

        <script src="<?php echo e(asset('')); ?>assets/admin/js/app.js"></script>


        <?php if($massage = Session::get('success')): ?>
        <script>
            Swal.fire({
          position: "top-end",
          icon: "success",
          title: "<?php echo e($massage); ?>",
          showConfirmButton: !1,
          timer: 3000
          })
          Swal();
        </script>
        <?php endif; ?>


        <?php if($massage = Session::get('error')): ?>
        <script>
            Swal.fire({
        position: "top-end",
        icon: "Error",
        title: "<?php echo e($massage); ?>",
        showConfirmButton: !1,
        timer: 3000
        })
        Swal();
        </script>
        <?php endif; ?>




<script>
$(document).ready(function() {
    // Initialize Dropify
    $('.dropify').dropify();
});
$(document).ready(function() {
    $('#summernote').summernote();
});

</script>
<?php /**PATH C:\xampp-8-1\htdocs\sawari\resources\views/admin/inc/script.blade.php ENDPATH**/ ?>