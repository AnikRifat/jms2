<section class="section-paddings best-services-area">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="section-title-version-2-black  text-center">
                    <h2>Why we are the best</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum
                    </p>
                </div>
            </div>
        </div>


        <div class="partner-slider-2">

<?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="m-4">
    <div class="single-best-services">
        <div class="services-image">
            <a href="#"><img src="<?php echo e(asset('uploads/features/' . $feature->image)); ?>" alt="">
            </a>
        </div>
        <div class="services-content">
            <a href="#">
                <h4><?php echo e($feature->title); ?></h4>
            </a>
            <p><?php echo e($feature->description); ?></p>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>


    </div>
</section>
<?php /**PATH C:\xampp\htdocs\sawari\resources\views/web/component/us.blade.php ENDPATH**/ ?>