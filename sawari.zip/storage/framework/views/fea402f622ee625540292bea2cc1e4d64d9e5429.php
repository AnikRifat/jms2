    <!-- jquery -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/vendor/jquery-3.2.0.min.js"></script>
    <!-- bootstrap js -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/bootstrap.min.js"></script>
    <!-- owl.carousel js -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/owl.carousel.min.js"></script>
    <!-- slick js -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/slick.min.js"></script>
    <!-- meanmenu js -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/jquery.meanmenu.min.js"></script>
    <!-- jquery-ui js -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/jquery-ui.min.js"></script>
    <!-- wow js -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/wow.min.js"></script>
    <!-- counter js -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/jquery.counterup.min.js"></script>
    <!-- Countdown js -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/jquery.countdown.min.js"></script>
    <!-- waypoints js -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/jquery.waypoints.min.js"></script>
    <!-- Isotope js -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/isotope.pkgd.min.js"></script>
    <!-- magnific js -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/jquery.magnific-popup.min.js"></script>
    <!-- Image loaded js -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/imagesloaded.pkgd.min.js"></script>
    <!-- chossen js -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/chosen.jquery.min.js"></script>
    <!-- Revolution JS -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/assets/revolution/jquery.themepunch.revolution.min.js"></script>
    <script src="<?php echo e(asset('')); ?>assets/web/js/assets/revolution/jquery.themepunch.tools.min.js"></script>
    <script src="<?php echo e(asset('')); ?>assets/web/js/assets/revolution/extensions/revolution.extension.actions.min.js"></script>
    <script src="<?php echo e(asset('')); ?>assets/web/js/assets/revolution/extensions/revolution.extension.carousel.min.js"></script>
    <script src="<?php echo e(asset('')); ?>assets/web/js/assets/revolution/extensions/revolution.extension.kenburn.min.js"></script>
    <script src="<?php echo e(asset('')); ?>assets/web/js/assets/revolution/extensions/revolution.extension.layeranimation.min.js"></script>
    <script src="<?php echo e(asset('')); ?>assets/web/js/assets/revolution/extensions/revolution.extension.migration.min.js"></script>
    <script src="<?php echo e(asset('')); ?>assets/web/js/assets/revolution/extensions/revolution.extension.navigation.min.js"></script>
    <script src="<?php echo e(asset('')); ?>assets/web/js/assets/revolution/extensions/revolution.extension.parallax.min.js"></script>
    <script src="<?php echo e(asset('')); ?>assets/web/js/assets/revolution/extensions/revolution.extension.slideanims.min.js"></script>
    <script src="<?php echo e(asset('')); ?>assets/web/js/assets/revolution/extensions/revolution.extension.video.min.js"></script>
    <script src="<?php echo e(asset('')); ?>assets/web/js/assets/revolution/revolution.js"></script>
     <!-- modernizr css -->
 <script src="<?php echo e(asset('')); ?>assets/web/js/vendor/modernizr-2.8.3.min.js"></script>
    <!-- plugin js -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/plugins.js"></script>
    <!-- select2 js -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/select2.min.js"></script>
    <script src="<?php echo e(asset('')); ?>assets/web/js/colors.js"></script>
    <!-- customSelect Js -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/jquery-customselect.js"></script>
    <!-- custom js -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/custom.js"></script>
<?php /**PATH /home8/thesawari/public_html/resources/views/web/inc/script.blade.php ENDPATH**/ ?>