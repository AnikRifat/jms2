<?php $__env->startSection('main-content'); ?>
    <div class="main-content">

        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                            <h4 class="mb-sm-0 font-size-18">Edit Package</h4>

                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">package</a></li>
                                    <li class="breadcrumb-item active">Edit Package</li>
                                </ol>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- end page title -->


                <div class="row">
                    <div class="col-xl-12">
                        <div class="card">
                            <div class="card-body">
                                <form method="POST" action="<?php echo e(route('packages.update', $package->id)); ?>"
                                    enctype="multipart/form-data">
                                    <?php echo method_field('PUT'); ?>
                                    <?php echo csrf_field(); ?>
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label for="title" class="form-label">Title</label>
                                            <input type="text" class="form-control" id="title" name="title"
                                                value="<?php echo e($package->title); ?>" required>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="subtitle" class="form-label">Subtitle</label>
                                            <input type="text" class="form-control" id="subtitle" name="subtitle"
                                                value="<?php echo e($package->subtitle); ?>" required>
                                        </div>
                                        <div class="col-md-12">
                                            <label for="description" class="form-label">Description</label>
                                            <textarea class="form-control" id="summernote" name="description" rows="5">
                                        <?php echo $package->description; ?>

                                    </textarea>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="price" class="form-label">Price</label>
                                            <div class="input-group">
                                                <span class="input-group-text">$</span>
                                                <input type="number" class="form-control" id="price" name="price"
                                                    value="<?php echo e($package->price); ?>" required>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="location" class="form-label">Location</label>
                                            <input type="text" class="form-control" id="location" name="location"
                                                value="<?php echo e($package->location); ?>" required>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="duration" class="form-label">Duration (in days)</label>
                                            <input type="text" class="form-control" id="duration" name="duration"
                                                value="<?php echo e($package->duration); ?>" required>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="min_age" class="form-label">Minimum Age</label>
                                            <input type="number" class="form-control" id="min_age" name="min_age"
                                                value="<?php echo e($package->min_age); ?>" required>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="max_people" class="form-label">Max People</label>
                                            <input type="number" class="form-control" id="max_people" name="max_people"
                                                value="<?php echo e($package->max_people); ?>" required>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="landing" class="form-label">Landing</label>
                                            <input type="text" class="form-control" id="landing" name="landing"
                                                value="<?php echo e($package->landing); ?>" required>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="check_in" class="form-label">Check In</label>
                                            <input type="date" class="form-control" id="check_in" name="check_in"
                                                value="<?php echo e($package->check_in); ?>" required>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="check_out" class="form-label">Check Out</label>
                                            <input type="date" class="form-control" id="check_out" name="check_out"
                                                value="<?php echo e($package->check_out); ?>" required>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="tour_map" class="form-label">Tour Map</label>
                                            <input type="text" class="form-control" id="tour_map" name="tour_map"
                                                value="<?php echo e($package->tour_map); ?>" required>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="service" class="form-label">Under Service of :</label>
                                            <select id="service" name="service_id" class="form-select">

                                                <option selected="">Choose...</option>
                                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($service->id); ?>"
                                                        <?php if($package->service_id == $service->id): ?> selected <?php endif; ?>>
                                                        <?php echo e($service->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="image" class="form-label">Image</label>
                                            <input type="file" class="form-control dropify" id="image"
                                                name="image"
                                                data-default-file="<?php echo e(asset('uploads/packages/' . $package->image)); ?>">
                                        </div>
                                        <div class="col-md-12 mt-3">
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </div>

                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>

            </div> <!-- container-fluid -->
        </div> <!-- page-content -->


        
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp-8-1\htdocs\sawari\resources\views/admin/pages/package/edit.blade.php ENDPATH**/ ?>