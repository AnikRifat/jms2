<!DOCTYPE html>
<html class="no-js" lang="zxx">
<head>
    <?php echo $__env->make('web.inc.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('web.inc.syles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<!-- Preloader -->

 <!-- header area end here -->
<?php echo $__env->make('web.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- slider area start here -->
<?php echo $__env->yieldContent('main-body'); ?>
<?php echo $__env->make('web.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ============================
    		JavaScript Files
    ============================= -->
<?php echo $__env->make('web.inc.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('script'); ?>
</body>


</html>
<?php /**PATH /home8/thesawari/public_html/resources/views/web/app/app.blade.php ENDPATH**/ ?>