<?php $__env->startSection('main-body'); ?>
<div class="main-body">
    <?php echo $__env->make('web.component.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="section-paddings welcome-area">

        <div class="container ">
            <div class="row">
                <div class="col-md-12">
                    <div class="single-welcome-text">
                        <div class="section-title-version-2-black text-center">
                            <h2>About Us</h2>
                            <p><?php echo e($content->about_title); ?>

                            </p>
                            <br>
                            <?php echo e($content->about_subtitle); ?>

                            <br><br>

                        </div>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="single-welcome-area text-center">
                        <div class="single-image mt-5">
                            <img src="<?php echo e(asset('uploads/content/' . $content->about_image)); ?>" alt=""
                              class="img-thumbnail img-responsive">
                        </div>

                    </div>
                </div>

                <div class="col-md-6">
                    <div class="welcome-content" style="padding-top: 10px">
                        <p>

                            <br>
                            <?php echo $content->about_content; ?>

                        </p>
                        
                    </div>
                </div>
                <!-- welcome area left side end -->

                <!-- welcome area right side end -->
            </div>
        </div>
    </section>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sawari\resources\views/web/pages/about.blade.php ENDPATH**/ ?>