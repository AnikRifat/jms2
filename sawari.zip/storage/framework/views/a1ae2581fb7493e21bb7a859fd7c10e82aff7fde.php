

<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($service->packages->count() >0): ?>
<section class="popular-packages pb-70 pt-100">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-title text-center">
                    <h2>Our Leatest <?php echo e($service->title); ?> packges</h2>
                    <p><?php echo e($service->description); ?> </p>
                    
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $service->packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-6">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="<?php echo e(asset('uploads/packages/'.$package->image)); ?>" alt="">
                        </a>
                    </div>
                    <div class="package-content">
                        <h3><?php echo e($package->title); ?></h3>
                        <p><?php echo e($package->subtitle); ?> <span>$<?php echo e($package->price); ?></span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="<?php echo e(route('package.details',$package->title)); ?>" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <?php if($service->packages->count() >0): ?>
        <div class="text-center">
            <a href="" class="travel-booking-btn btn-warning hvr-shutter-out-horizontal">view all</a>
        </div>
        <?php endif; ?>

    </div>
</section>
<?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home8/thesawari/public_html/resources/views/web/component/package.blade.php ENDPATH**/ ?>