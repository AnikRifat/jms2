
    <meta charset="UTF-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="<?php echo e($content->website_Description); ?>">
    <meta name="keywords" content="Tour, Travel, Travel Agency">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($content->website_name); ?> - Tour, Travel & Travel Agency</title>


<?php /**PATH /home8/thesawari/public_html/resources/views/web/inc/head.blade.php ENDPATH**/ ?>