<header class="index-2">
    <!-- header top start -->
    <div class="header-top-area ">
        <div class="container">
            <div class="row">
                <div class="header-top-left">
                    <div class="col-md-9 col-sm-9 col-xs-12">
                        <ul class="header-top-contact">
                            <li><i class="fa fa-map-marker" aria-hidden="true"></i><?php echo e($content->website_address); ?></li>
                            <li><i class="fa fa-phone" aria-hidden="true"></i><?php echo e($content->website_phone); ?></li>
                            <li><i class="fa fa-envelope-o" aria-hidden="true"></i><?php echo e($content->website_email); ?></li>
                        </ul>
                    </div>
                </div>
                <div class="header-top-right text-right">
                    <div class="col-md-3 col-xs-12 book-tab">
                        <div class="book-btn">
                            <a href="#">Book Online</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- header top end -->

    <div class="header-bottom-area" id="stick-header">
        <div class="container">
            <div class="row">
                <div class="col-md-2 col-sm-2 col-xs-12 tap-v-responsive">
                    <div class="logo-area">
                        <a href="<?php echo e(route('index')); ?>"><img
                              src="<?php echo e(asset('uploads/content/' . $content->website_logo)); ?>" alt="">
                        </a>
                    </div>
                </div>
                <!-- main menu start here -->
                <div class="col-md-10">
                    <nav>
                        <ul class="main-menu text-right">
                            <li class="active"><a href="index.html">Home</a>

                            </li>
                            <li><a href="package-version-one.html">Package List</a>
                                <ul class="dropdown">
                                    <li><a href="package-version-one.html">Package One</a>
                                    </li>
                                    <li><a href="package-version-two.html">Package Two</a>
                                    </li>
                                    <li><a href="single-package.html">Package Details</a>
                                    </li>
                                </ul>
                            </li>


                            <li><a href="blog-version-one.html">Blog</a>

                            </li>
                            <li><a href="contact.html">About Us</a>
                            </li>
                            <li><a href="contact.html">Contact</a>
                            </li>
                        </ul>
                    </nav>
                </div> <!-- main menu end here -->
            </div>
        </div>
    </div> <!-- header-bottom area end here -->
</header> <!-- header area end here --><?php /**PATH /home8/thesawari/public_html/resources/views/web/inc/header.blade.php ENDPATH**/ ?>