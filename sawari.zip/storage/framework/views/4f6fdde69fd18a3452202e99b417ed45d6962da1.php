
    <!-- guide and Expert Advice strat -->
    <section class="section-paddings">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="section-title text-center">
                        <h2>Travel guide and Expert Advice</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus orci vel nibh aliquam laoreet Aenean accumsan </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <!-- single travel blog-->
                <div class="col-md-4 col-sm-6 phone-layout-s">
                    <div class="single-travel-blog">
                        <div class="blog-image">
                            <a href="#"><img src="<?php echo e(asset('')); ?>assets/web/images/blog/1.jpg" alt="">
                            </a>
                        </div>
                        <div class="blog-content">
                            <div class="blog-meta">
                                <div class="post-date">
                                    <span><i class="fa fa-calendar"></i> 12 Sep, 2018</span>
                                </div>
                                <ul class="post-social">
                                    <li><a href="#"><i class="fa fa-comments"></i>3</a>
                                    </li>
                                    <li><a href="#"><i class="fa fa-heart-o"></i>43</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="blog-post-content">
                                <h4>Tips for taking a long-term trip with kids.</h4>
                                <p>Lorem ipsum dolor sit amet consepctetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus.</p>
                                <a href="#">Read More <i class="fa fa-angle-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div> <!--end single travel guide & security-->

                <div class="col-md-4 col-sm-6 phone-layout-s">
                    <div class="single-travel-blog">
                        <div class="blog-image">
                            <a href="#"><img src="<?php echo e(asset('')); ?>assets/web/images/blog/2.jpg" alt="">
                            </a>
                        </div>
                        <div class="blog-content">
                            <div class="blog-meta">
                                <div class="post-date">
                                    <span><i class="fa fa-calendar"></i> 12 Aug, 2018</span>
                                </div>
                                <ul class="post-social">
                                    <li><a href="#"><i class="fa fa-comments"></i>3</a>
                                    </li>
                                    <li><a href="#"><i class="fa fa-heart-o"></i>43</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="blog-post-content">
                                <h4>Tips for taking a long-term trip with kids.</h4>
                                <p>Lorem ipsum dolor sit amet consepctetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus.</p>
                                <a href="#">Read More <i class="fa fa-angle-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div> <!--end single travel guide & security-->

                <div class="col-md-4 col-sm-6 phone-layout-s">
                    <div class="single-travel-blog">
                        <div class="blog-image">
                            <a href="#"><img src="<?php echo e(asset('')); ?>assets/web/images/blog/3.jpg" alt="">
                            </a>
                        </div>
                        <div class="blog-content">
                            <div class="blog-meta">
                                <div class="post-date">
                                    <span><i class="fa fa-calendar"></i> 12 Jul, 2018</span>
                                </div>
                                <ul class="post-social">
                                    <li><a href="#"><i class="fa fa-comments"></i>3</a>
                                    </li>
                                    <li><a href="#"><i class="fa fa-heart-o"></i>43</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="blog-post-content">
                                <h4>Tips for taking a long-term trip with kids.</h4>
                                <p>Lorem ipsum dolor sit amet consepctetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus.</p>
                                <a href="#">Read More <i class="fa fa-angle-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div> <!-- single travel guide & security end-->
            </div>
        </div>
    </section> <!--End guide and Expert Advice strat -->
<?php /**PATH C:\xampp-8-1\htdocs\sawari\resources\views/web/component/blog.blade.php ENDPATH**/ ?>