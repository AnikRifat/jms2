<footer class="footer-area">
    <div class="container">
        <div class="row">
            <!-- footer left -->
            <div class="col-md-3 col-sm-6">
                <div class="single-footer">
                    <div class="footer-title">
                        <a href="#"><img src="<?php echo e(asset('')); ?>assets/web/images/logo.png" alt="">
                        </a>
                    </div>
                    <div class="footer-left">
                        <div class="footer-logo">
                            <p><?php echo e($content->website_description); ?></p>
                        </div>
                        <ul class="footer-contact">
                            <li><img class="map" src="<?php echo e(asset('')); ?>assets/web/images/icon/map.png"
                                  alt=""><?php echo e($content->website_address); ?></li>
                            <li><img class="map" src="<?php echo e(asset('')); ?>assets/web/images/icon/phone.png"
                                  alt=""><?php echo e($content->website_phone); ?></li>
                            <li><img class="map" src="<?php echo e(asset('')); ?>assets/web/images/icon/gmail.png"
                                  alt=""><?php echo e($content->website_email); ?></li>
                        </ul>
                    </div>
                </div>
            </div> <!-- footer left -->

            <div class="col-md-3 col-sm-6">
                <div class="single-footer">
                    <div class="single-recent-post">
                        <div class="footer-title">
                            <h3>Recent News</h3>
                        </div>
                        <ul class="recent-post">
<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
    <a href="#">
        <div class="post-thum">
            <img src="<?php echo e(asset('uploads/blogs/' . $blog->image)); ?>" style="height: 35px;" alt=""
              class="img-rounded">
        </div>
        <div class="post-content">
            <p><?php echo e($blog->title); ?>

            </p>
            <span><?php echo e(\Carbon\Carbon::parse($blog->created_at)->format('d M, Y')); ?></span>
        </div>
    </a>
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </ul>
                    </div>
                </div>
            </div> <!-- footer latest news -->

            <!-- footer destination -->
            <div class="col-md-3 col-sm-6">
                <div class="single-footer">
                    <div class="footer-title">
                        <h3>Destination</h3>
                    </div>
                    <ul class="footer-gallery">
                        <?php $__currentLoopData = $destinations->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="#">
                                <div class="image-overlay">
                                    <img src="<?php echo e(asset('uploads/destinations/' . $destination->image)); ?>" style="height:100px" alt="">
                                    <div class="overly-city">
                                        <span><?php echo e($destination->title); ?></span>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div> <!-- footer destination -->

            <!-- footer contact -->
            <div class="col-md-3 col-sm-6 f-phone-responsive">
                <div class="single-footer">
                    <div class="footer-title">
                        <h3>Quick Contact</h3>
                    </div>
                    <div class="footer-contact-form">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m17!1m12!1m3!1d3649.9477014223007!2d90.35606461538562!3d23.820458692012323!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m2!1m1!2s!5e0!3m2!1sen!2sbd!4v1680949886547!5m2!1sen!2sbd" width="200" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                    <div class="footer-social-media">
                        <div class="social-footer-title">
                            <h3>Follow Us</h3>
                        </div>
                        <ul class="footer-social-link">
                            <li class="facebook"><a href="#"><i class="fa fa-facebook"></i></a>
                            </li>
                            <li class="twitter"><a href="#"><i class="fa fa-twitter"></i></a>
                            </li>
                            <li class="linkedin"><a href="#"><i class="fa fa-linkedin"></i></a>
                            </li>
                            <li class="gplus"><a href="#"><i class="fa fa-google-plus"></i></a>
                            </li>
                            <li class="youtube"><a href="#"><i class="fa fa-youtube-play"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- footer contact -->
        </div>

        <div class="row">
            <div class="footer-bottom">
                <div class="col-md-5">
                    <div class="copyright">
                        <p>Copyright &copy; 2023 Sawari By <a href="https://monoputo.com/"
                              target="_blank"><span>MonoPuto</span></a></p>
                    </div>
                </div>
                <div class="col-md-7">
                    <ul class="payicon pull-right">
                        <li>We Accept</li>
                        <li><img src="<?php echo e(asset('')); ?>assets/web/images/payicon01.png" alt=""></li>
                        <li><img src="<?php echo e(asset('')); ?>assets/web/images/payicon02.png" alt=""></li>
                        <li><img src="<?php echo e(asset('')); ?>assets/web/images/payicon03.png" alt=""></li>
                        <li><img src="<?php echo e(asset('')); ?>assets/web/images/payicon04.png" alt=""></li>
                        <li><img src="<?php echo e(asset('')); ?>assets/web/images/payicon05.png" alt=""></li>
                        <li><img src="<?php echo e(asset('')); ?>assets/web/images/payicon06.png" alt=""></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer> <!-- end footer -->

<div class="to-top pos-rtive">
    <a href="#"><i class="fa fa-angle-up"></i></a>
</div><!-- Scroll to top-->
<?php /**PATH C:\xampp\htdocs\sawari\resources\views/web/inc/footer.blade.php ENDPATH**/ ?>