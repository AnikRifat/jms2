<?php $__env->startSection('main-body'); ?>
<div class="main-body">

    <!-- blog breadcrumb version one strat here -->
    <section class="breadcrumb-blog-version-one">
        <div class="single-bredcurms" style="background-image:url('images/bercums/contact-page.jpg');">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="bredcrums-content">
                            <h2>Blog Post</h2>
                            <ul>
                                <li><a href="<?php echo e(route('index')); ?>">Home</a></li>
                                <li class="active"><a href="blog-single.html">Blog-Post</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- blog breadcrumb version one end here -->

    <!-- Start blog -->
    <section id="blog" class="section-paddings single section page">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-12 col-xs-12">
                    <div class="col-md-12">
                        <!-- Single blog -->
                        <div class="single-blog">
                            <div class="blog-head">
                                <img src="<?php echo e(asset('uploads/blogs/' . $blog->image)); ?>" alt="#">
                            </div>
                            <div class="blog-content">
                                <h2><?php echo e($blog->title); ?></h2>
                                <div class="meta">
                                    
                                    <span><i
                                          class="fa fa-calender"></i><?php echo e(\Carbon\Carbon::parse($blog->created_at)->format('d M, Y')); ?></span>
                                </div>
                                <p>
                                    <?php echo $blog->description; ?>

                                </p>
                            </div>
                        </div>
                        <!--/ End Single blog -->

                    </div>

                </div>

                <div class="col-md-4 col-sm-12 col-xs-12">
                    <!-- Blog Sidebar -->
                    <div class="blog-sidebar">
                        <div class="single-sidebar tags">
                            <h2>Popular <span>Services</span></h2>
                            <ul>
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('service.package',$service->title)); ?>"><?php echo e($service->title); ?> <span> (<?php echo e($service->packages->count()); ?>)</span></a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>



                        <!-- Single Sidebar -->
                        <div class="single-sidebar latest">
                            <h2>Popular Post</h2>

                            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-post">
                                <div class="post-info">
                                    <h4><a href="#"><?php echo e($blog->title); ?></a></h4>
                                    <p><?php echo e(\Carbon\Carbon::parse($blog->created_at)->format('d M, Y')); ?></p>
                                </div>
                            </div> <!-- End Single Post -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>
                        <!--/ End Single Sidebar -->
         <!-- Single Sidebar -->
         <div class="single-sidebar category">
            <h2>Leatest Packages</h2>
            <ul>
                <?php $__currentLoopData = $packages->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('package.details', $package->title)); ?>"><i class="fa fa-angle-double-right"></i><?php echo e($package->title); ?></a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </ul>
        </div>
        <!--/ End Single Sidebar -->

                    </div>
                    <!--/ End Blog Sidebar -->
                </div>
            </div>
        </div>
    </section>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sawari\resources\views/web/pages/blog/details.blade.php ENDPATH**/ ?>