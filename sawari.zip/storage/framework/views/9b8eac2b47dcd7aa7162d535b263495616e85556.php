


<?php $__env->startSection('main-body'); ?>
<div class="main-body">
<!-- blog breadcrumb version one strat here -->
<section class="breadcrumb-blog-version-one">
	<div class="single-bredcurms" style="background-image:url('images/bercums/Single-Package-Details.jpg');">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div class="bredcrums-content">
						<h2>Package</h2>
						<ul>
							<li><a href="index.html">Home</a>
							</li>
							<li class="active"><a href="single-package.html">Package Details</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</section><!-- blog breadcrumb version one end here -->

<section class="section-paddings single-package-area">
	<div class="container">
		<div class="row">
			<!-- single package tab with details -->
			<div class="col-md-8 col-sm-12">
				<div class="single-package-details">
					<div class="single-package-title">
						<h2><?php echo e($package->title); ?></h2>
					</div>
					<ul class="package-content">
						<li><?php echo e($package->subtitle); ?></li>

						<li><?php echo e($package->price); ?> ৳</li>
					</ul>
					<div class="package-features-image">
						<img src="<?php echo e(asset('uploads/packages/' . $package->image)); ?>" alt="" class="img-responsove border-raduis-3">
					</div>
				</div><!-- tab menu strat -->

				<div class="package-tab-menu">
					<ul class="package-tab-menu" role="tablist" id="tab7">
						<li role="presentation" class="active"><a href="#description" aria-controls="description" role="tab" data-toggle="tab">Description</a>
						</li>
						<li role="presentation"><a href="#itinerary" aria-controls="itinerary" role="tab" data-toggle="tab">Tour Itinerary</a>
						</li>
						<li role="presentation"><a href="#map" aria-controls="map" role="tab" data-toggle="tab">Tour Map</a>
						</li>
						<li role="presentation"><a href="#video" aria-controls="video" role="tab" data-toggle="tab">Additional Info</a>
						</li>

					</ul>
				</div><!-- tab menu end -->

				<!-- tab content start -->
				<div class="row">
					<!-- tabs content -->
					<div class="tab-content">
						<div role="tabpanel" class="tab-pane fade in active" id="description">
							<div class="row">
								<!-- left content -->
								<div class="col-md-12 col-sm-12">
									<div class="tour-description">
										<h4>Tour Description</h4>
										<p><?php echo $package->description; ?></p>
									</div>

								</div><!-- left-content -->

							</div>
						</div>

						<div role="tabpanel" class="tab-pane fade" id="itinerary">
							<div class="row">
								<div class="col-md-12 col-sm-12">
									<div class="tour-description">
										<h4>Tour Description</h4>
										<div class="main-timeline">
											<!-- single timeline -->
											<div class="timeline">
												<div class="timeline-content left">
													<span class="timeline-icon">1</span>
													<h4>Day 1: Meeting The All Members</h4>
													<p>Tourist attractions people foreign sleep overnight housing. Gerimrany group discount tour operator. Airplane couchsurfing Moi scow ma ps uncharted luxury train guest tour operator German y busre laxation. Paris overnight Japan Tripit territory international carren tal Pacific outdoor Turkey. Country international to urist attractions mil es train Moscow guide. Japan horse riding money Bacel ona Buda pest yach.</p>
												</div>
											</div><!-- single timeline -->

											<!-- single timeline -->
											<div class="timeline">
												<div class="timeline-content left">
													<span class="timeline-icon">2</span>
													<h4>Day 2: Unforgettable Journey</h4>
													<p>Tourist attractions people foreign sleep overnight housing. Gerimrany group discount tour operator. Airplane couchsurfing Moi scow ma ps uncharted luxury train guest tour operator German y busre laxation. Paris overnight.</p>
												</div>
											</div><!-- single timeline -->

											<!-- single timeline -->
											<div class="timeline">
												<div class="timeline-content left">
													<span class="timeline-icon">3</span>
													<h4>Day 3: Night Party</h4>
													<p>Tourist attractions people foreign sleep overnight housing. Gerimrany group discount tour operator. Airplane couchsurfing Moi scow ma ps uncharted luxury train guest tour operator German y busre laxation. Paris overnight.</p>
												</div>
											</div><!-- single timeline -->

											<!-- single timeline -->
											<div class="timeline">
												<div class="timeline-content left">
													<span class="timeline-icon">4</span>
													<h4>Day 4: Time To Say Good Bay</h4>
													<p>Tourist attractions people foreign sleep overnight housing. Gerimrany group discount tour operator. Airplane couchsurfing Moi scow ma ps uncharted luxury train guest tour operator German y busre laxation. Paris overnight.</p>
												</div>
											</div><!-- single timeline -->
										</div>
									</div>
								</div>
							</div>
						</div>

						<div role="tabpanel" class="tab-pane fade" id="map">
							<div class="row">
								<div class="col-md-12 col-sm-12">
									<div class="tour-description">
										<h4>Map Tour</h4>
										<!-- map -->
										<div class="mapp" id="overlay">
											<iframe id="maping" src="<?php echo e($package->tour_map); ?>" allowfullscreen></iframe>
										</div><!-- map -->
									</div>
								</div>
							</div>
						</div>

						<!-- video tab content start -->
						<div role="tabpanel" class="tab-pane fade" id="video">
							<div class="row">
								<div class="col-md-12 col-sm-12">
									<div class="tour-description">
										<h4>Aditinal Information</h4>
										<div class="row">
                                            <div class="col-md-7 col-sm-7">
                                                <div class="info-list">
                                                    <p><span><i class="fa fa-map-marker"></i></span>Location</p>
                                                    <p><span><i class="fa fa-clock-o"></i></span>Duration</p>
                                                    <p><span><i class="fa fa-user"></i></span>Min Age</p>
                                                    <p><span><i class="fa fa-users"></i></span>Max People</p>
                                                    <p><span><i class="fa fa-plane"></i></span>Landing</p>
                                                    <p><span><i class="fa fa-calendar-check-o"></i></span>Check In</p>
                                                    <p><span><i class="fa fa-calendar-minus-o"></i></span>Check Out</p>
                                                </div>
                                            </div>
                                            <div class="col-md-5 col-sm-5">
                                                <div class="info-details">
                                                    <p><?php echo e($package->location); ?></p>
                                                    <p><?php echo e($package->duration); ?></p>
                                                    <p><?php echo e($package->min_age); ?></p>
                                                    <p><?php echo e($package->max_people); ?></p>
                                                    <p><?php echo e($package->landing); ?></p>
                                                    <p><?php echo e($package->check_in); ?></p>
                                                    <p><?php echo e($package->check_out); ?></p>
                                                </div>
                                            </div>
                                        </div>
									</div>
								</div>
							</div>
						</div><!-- video tab content end -->

					</div><!-- tabs content-->
				</div><!-- tab content end -->
			</div><!-- single package tab with details -->

			<!-- booking form start here -->
			<div class="col-md-4 col-sm-12">
				<aside>
					<div class="booking-form">
						<div class="booking-title">
							<h2>Book This Tour</h2>
						</div>
						<form action="#" method="post">
							<div class="form-group">
								<input type="text" class="form-control" id="name" placeholder="Name *">
							</div>
							<div class="form-group">
								<input type="email" class="form-control" id="confirm_email" placeholder="Confirm E-mail *">
							</div>
							<div class="form-group">
								<input type="tel" class="form-control" id="number" placeholder="Phone Number *">
							</div>
							<div class="form-group">
								<input type="text" class="form-control" id="booking-date" placeholder="dd-mm-yy *">
							</div>
							<div class="form-group">
								<input type="text" class="form-control" id="ticket" placeholder="Number Of Tickets *">
							</div>
							<div class="form-group">
								<textarea name="messgae" id="message" cols="30" rows="10" class="form-control" placeholder="Message *"></textarea>
							</div>
							<div class="form-group">
								<button type="submit" class="check-availability">Check Availability</button>
							</div>
							<div class="form-group">
								<button type="submit" class="booking-confirm hvr-shutter-out-horizontal">Book Now</button>
							</div>
						</form>
					</div>
				</aside><!-- adverestment start here-->

				<div class="adding-form">
					<div class="addfor-bg">
						<div class="add-content">
							<h3>Any Question?</h3>
							<p>Lorem ipsum dolor sit amet, consectet ur adipiscing elit, sedpr do eiusmod tempor incididunt ut.</p>
							<ul class="contact-for-add">
								<li><img src="images/icon/phone.png" alt="">+123-456-7890</li>
								<li><img src="images/icon/gmail.png" alt="">info@yourcompany.com</li>
							</ul>
						</div>
					</div>
				</div><!-- adverestment start here-->
			</div><!-- booking form end here -->
		</div>
	</div>
</section>

<!-- realted tour start here -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home8/thesawari/public_html/resources/views/web/pages/package/details.blade.php ENDPATH**/ ?>