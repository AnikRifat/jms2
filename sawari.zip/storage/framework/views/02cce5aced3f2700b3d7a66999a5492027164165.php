<header class="index-2">
    <!-- header top start -->
    <div class="header-top-area ">
        <div class="container">
            <div class="row">
                <div class="header-top-left">
                    <div class="col-md-9 col-sm-9 col-xs-12">
                        <ul class="header-top-contact">
                            <li><i class="fa fa-map-marker" aria-hidden="true"></i><?php echo e($content->website_address); ?></li>
                            <li><i class="fa fa-phone" aria-hidden="true"></i><?php echo e($content->website_phone); ?></li>
                            <li><i class="fa fa-envelope-o" aria-hidden="true"></i><?php echo e($content->website_email); ?></li>
                        </ul>
                    </div>
                </div>
                <div class="header-top-right text-right">
                    <div class="col-md-3 col-xs-12 book-tab">
                        <div class="book-btn">
                            <a href="#">Book Online</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- header top end -->

    <div class="header-bottom-area" id="stick-header">
        <div class="container">
            <div class="row">
                <div class="col-md-2 col-sm-2 col-xs-12 tap-v-responsive">
                    <div class="logo-area">
                        <a href="<?php echo e(route('index')); ?>"><img
                              src="<?php echo e(asset('uploads/content/' . $content->website_logo)); ?>" alt="">
                        </a>
                    </div>
                </div>
                <!-- main menu start here -->
                <div class="col-md-10">
                    <nav>
                        <ul class="main-menu text-right">
                            <li class="active"><a href="<?php echo e(route('index')); ?>">Home</a>

                            </li>
                            <li><a href="<?php echo e(route('packages.all')); ?>">Packages</a>
                                <ul class="dropdown">
                                   <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <li><a href="<?php echo e(route('service.package',$service->title)); ?>"><?php echo e($service->title); ?></a>
                                   </li>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>
                            </li>


                            <li><a href="<?php echo e(route('blogs.all')); ?>">Blogs</a>

                            </li>
                            <li><a href="<?php echo e(route('about')); ?>">About Us</a>
                            </li>
                            <li><a href="<?php echo e(route('contact')); ?>">Contact</a>
                            </li>
                        </ul>
                    </nav>
                </div> <!-- main menu end here -->
            </div>
        </div>
    </div> <!-- header-bottom area end here -->
</header> <!-- header area end here -->
<?php /**PATH C:\xampp\htdocs\sawari\resources\views/web/inc/header.blade.php ENDPATH**/ ?>