<?php $__env->startSection('main-body'); ?>
<div class="main-body">
<?php echo $__env->make('web.component.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="tabbased-search-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="tabbable-menu">
                        <ul class="tab-menu" id="myTab1">
                            <li class="active"><h6><a href="#hotels" data-easein="fadeIn">Hotels<img src="<?php echo e(asset('')); ?>assets/web/images/icon/hotel.png" alt=""></a></h6>
                            </li>
                            <li><h6><a href="#tour" data-easein="fadeIn">Tour<img src="<?php echo e(asset('')); ?>assets/web/images/icon/tour.png" alt=""></a></h6>
                            </li>
                            <li><h6><a href="#flights" data-easein="fadeIn">Flights<img src="<?php echo e(asset('')); ?>assets/web/images/icon/fly.png" alt=""></a></h6>
                            </li>
                            <li><h6><a href="#vehicles" data-easein="fadeIn">Vehicles<img src="<?php echo e(asset('')); ?>assets/web/images/icon/car.png" alt=""></a></h6>
                            </li>
                            <li><h6><a href="#ship"  data-easein="fadeIn">Ship<img src="<?php echo e(asset('')); ?>assets/web/images/icon/ship.png" alt=""></a></h6>
                            </li>
                        </ul>
                    </div> <!-- tab menu end here -->

                    <!-- tab content strat here -->
                    <div class="tab-content" id="tab-content1">
                        <div class="tab-pane active" id="hotels">
                            <div class="hotels-form">
                                <form action="#" method="post">
                                    <div class="hotel-input-2 input-b">
                                        <input type="text" name="s" id="keyword" class="hotel-input-first" placeholder="Type Keyword">
                                    </div>
                                    <div class="hotel-input-4 input-b">
                                        <select id='standard1' name='standard' class='custom-select'>
                                            <option value=''>Select a Location</option>
                                            <option value='Us'>America</option>
                                            <option value='Canda'>Canada</option>
                                            <option value='london'>London</option>
                                            <option value='france'>Paris</option>
                                            <option value='bd'>Bangladesh</option>
                                        </select>
                                    </div>
                                    <div class="hotel-input-1 input-s">
                                        <input type="text" name="s" id="datepicker" class="hotel-input-first" placeholder="Check-In">
                                    </div>
                                    <div class="hotel-input-1 input-s">
                                        <input type="text" name="s" id="datepicker1" class="hotel-input-first" placeholder="Check-out">
                                    </div>
                                    <div class="hotel-input-1 input-s">
                                        <input type="number" name="s" id="number" class="hotel-input-first" placeholder="Guest">
                                    </div>
                                    <div class="hotel-input-1 input-s">
                                        <input type="text" name="s" id="budget" class="hotel-input-first" placeholder="Budget">
                                    </div>
                                    <div class="searc-btn-7">
                                        <button type="submit">Search</button>
                                    </div>
                                </form>
                            </div>
                        </div> <!-- hotel form end here -->

                        <div class="tab-pane" id="tour">
                            <div class="hotels-form">
                                <form action="#" method="post">
                                    <div class="hotel-input-4-23 input-b">
                                        <input type="text" name="s" id="keyword2" class="hotel-input-first" placeholder="Type Keyword">
                                    </div>
                                    <div class="hotel-input-4-23 input-b">
                                        <select id='standard2' name='standard' class='custom-select'>
                                            <option value=''>Select a Location</option>
                                            <option value='Us'>America</option>
                                            <option value='Canda'>Canada</option>
                                            <option value='london'>London</option>
                                            <option value='france'>Paris</option>
                                            <option value='bd'>Bangladesh</option>
                                        </select>
                                    </div>
                                    <div class="hotel-input-4-23 input-s">
                                        <input type="text" name="s" id="datepicker2" class="hotel-input-first" placeholder="Check-In Date">
                                    </div>
                                    <div class="hotel-input-4-23 input-s">
                                        <input type="number" name="s" id="number1" class="hotel-input-first" placeholder="Number of Guest">
                                    </div>
                                    <div class="searc-btn-7">
                                        <button type="submit">Search</button>
                                    </div>
                                </form>
                            </div>
                        </div> <!-- hotel form end here -->

                        <div class="tab-pane" id="flights">
                            <div class="flights-form">
                                <form action="#" method="post">
                                    <div class="tour-input-20 input-b">
                                        <select id='standard3' name='standard' class='custom-select'>
                                            <option value=''>Origin City or airport</option>
                                            <option value='Us'>America</option>
                                            <option value='Canda'>Canada</option>
                                            <option value='london'>London</option>
                                            <option value='france'>Paris</option>
                                            <option value='bd'>Bangladesh</option>
                                        </select>
                                    </div>
                                    <div class="tour-input-20 input-b">
                                        <select id='standard4' name='standard' class='custom-select'>
                                            <option value=''>Destination City</option>
                                            <option value='Us'>America</option>
                                            <option value='Canda'>Canada</option>
                                            <option value='london'>London</option>
                                            <option value='france'>Paris</option>
                                            <option value='bd'>Bangladesh</option>
                                        </select>
                                    </div>
                                    <div class="tour-input-15 input-s">
                                        <input type="text" name="s" id="datepicker3" class="hotel-input-first" placeholder="Daparture date">
                                    </div>
                                    <div class="tour-input-15 input-s">
                                        <input type="text" name="s" id="datepicker4" class="hotel-input-first" placeholder="Return date">
                                    </div>
                                    <div class="tour-input-15 input-b">
                                        <select id='nosearch' name='standard' class='custom-select'>
                                            <option value=''>Economy</option>
                                            <option value='Economy'>Economy</option>
                                            <option value='Business'>Business</option>
                                        </select>
                                    </div>
                                    <div class="tour-input-7-5 input-s input-xm">
                                        <select id='nosearch1' name='standard' class='custom-select'>
                                            <option value=''>Adult</option>
                                            <option value='1'>1</option>
                                            <option value='2'>2</option>
                                            <option value='3'>3</option>
                                            <option value='4'>4</option>
                                            <option value='5'>5</option>
                                            <option value='6'>6</option>
                                            <option value='7'>7</option>
                                            <option value='8'>8</option>
                                            <option value='9'>9</option>
                                            <option value='10'>10</option>
                                        </select>
                                    </div>
                                    <div class="tour-input-7-5  input-s input-xm">
                                        <select id='nosearch2' name='standard' class='custom-select'>
                                            <option value=''>Kids</option>
                                            <option value='1'>1</option>
                                            <option value='2'>2</option>
                                            <option value='3'>3</option>
                                            <option value='4'>4</option>
                                            <option value='5'>5</option>
                                            <option value='6'>6</option>
                                            <option value='7'>7</option>
                                            <option value='8'>8</option>
                                            <option value='9'>9</option>
                                            <option value='10'>10</option>
                                        </select>
                                    </div>
                                    <div class="searc-btn-7 flights-search-btn">
                                        <button type="submit">Search</button>
                                    </div>
                                </form>
                            </div>
                        </div> <!-- flights form start here -->

                        <div class="tab-pane" id="vehicles">
                            <div class="hotels-form">
                                <form action="#" method="post">
                                    <div class="hotel-input-4-23  input-s">
                                        <input type="text" name="s" id="pickupdate" class="hotel-input-first" placeholder="Pickup Date & time">
                                    </div>
                                    <div class="hotel-input-4-23 input-s">
                                        <input type="number" name="s" id="hours" class="hotel-input-first" placeholder="Hours">
                                    </div>
                                    <div class="hotel-input-4-23 input-s">
                                        <input type="text" name="s" id="pickup" class="hotel-input-first" placeholder="Pickup Location">
                                    </div>
                                    <div class="hotel-input-4-23 input-s">
                                        <input type="text" name="s" id="location" class="hotel-input-first" placeholder="Drop Location">
                                    </div>
                                    <div class="searc-btn-7">
                                        <button type="submit">Search</button>
                                    </div>
                                </form>
                            </div>
                        </div> <!-- vehicles form end here -->

                        <div class="tab-pane" id="ship">
                            <div class="hotels-form">
                                <form action="#" method="post">
                                    <div class="hotel-input-4-23 input-s">
                                        <input type="text" name="s" id="shippickupdate" class="hotel-input-first" placeholder="Pickup Date & time">
                                    </div>
                                    <div class="hotel-input-4-23 input-s">
                                        <input type="number" name="s" id="time" class="hotel-input-first" placeholder="Hours">
                                    </div>
                                    <div class="hotel-input-4-23 input-s">
                                        <input type="text" name="s" id="name" class="hotel-input-first" placeholder="Pickup Location">
                                    </div>
                                    <div class="hotel-input-4-23 input-s">
                                        <input type="text" name="s" id="drop-location" class="hotel-input-first" placeholder="Drop Location">
                                    </div>
                                    <div class="searc-btn-7">
                                        <button type="submit">Search</button>
                                    </div>
                                </form>
                            </div>
                        </div><!-- ship form end here -->
                    </div><!-- tab content end -->
                </div>
            </div>
        </div>
    </section> <!-- header tab based search area end-->
    <?php echo $__env->make('web.component.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->make('web.component.package', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!--end  popular packajge -->
    <section class="discount-bg">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="discount-content text-center">
                        <h2>50% Discount Offer!</h2>
                        <h3>Italy – All Stunning Places</h3>
                        <h4><span>$800</span> - 2 Persons - 4day, 5night Stay</h4>
                        <div class="discount-btn">
                            <a href="#" class="travel-primary-btn hvr-fade">Book Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="pb-70 pt-100">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="section-title text-center">
                        <h2>Most popular destination</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus orci vel nibh aliquam laoreet Aenean accumsan </p>
                    </div>
                </div>
            </div>
            <div class="destination-slider-active owl-carousel">
                <div class="single-destination">
                    <figure>
                        <a href="#"><img src="<?php echo e(asset('')); ?>assets/web/images/destination/1.jpg" alt="">
                        </a>
                        <figcaption>
                            <a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Read More</a>
                        </figcaption>
                    </figure>
                    <div class="des-city">
                        <a href="#"><i class="fa fa-map-marker"></i>Sydney, Australia</a>
                        <h4>Opera House <span>3 Tours</span></h4>
                    </div>
                </div> <!-- single popular destination  end-->

                <div class="single-destination">
                    <figure>
                        <a href="#"><img src="<?php echo e(asset('')); ?>assets/web/images/destination/2.jpg" alt="">
                        </a>
                        <figcaption>
                            <a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Read More</a>
                        </figcaption>
                    </figure>
                    <div class="des-city">
                        <a href="#"><i class="fa fa-map-marker"></i>London, Eangland</a>
                        <h4>Tower Bridge<span>5 Tours</span></h4>
                    </div>
                </div> <!-- single popular destination  end-->

                <div class="single-destination">
                    <figure>
                        <a href="#"><img src="<?php echo e(asset('')); ?>assets/web/images/destination/3.jpg" alt="">
                        </a>
                        <figcaption>
                            <a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Read More</a>
                        </figcaption>
                    </figure>
                    <div class="des-city">
                        <a href="#"><i class="fa fa-map-marker"></i>Paris, France</a>
                        <h4>Eiffel Tower<span>4 Tours</span></h4>
                    </div>
                </div> <!-- single popular destination  end-->

                <div class="single-destination">
                    <figure>
                        <a href="#"><img src="<?php echo e(asset('')); ?>assets/web/images/destination/4.jpg" alt="">
                        </a>
                        <figcaption>
                            <a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Read More</a>
                        </figcaption>
                    </figure>
                    <div class="des-city">
                        <a href="#"><i class="fa fa-map-marker"></i>New york, USA</a>
                        <h4>Statue Of Liberty<span>3 Tours</span></h4>
                    </div>
                </div> <!-- single popular destination  end-->

                <div class="single-destination">
                    <figure>
                        <a href="#"><img src="<?php echo e(asset('')); ?>assets/web/images/destination/5.jpg" alt="">
                        </a>
                        <figcaption>
                            <a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Read More</a>
                        </figcaption>
                    </figure>
                    <div class="des-city">
                        <a href="#"><i class="fa fa-map-marker"></i>Agra, India</a>
                        <h4>Tajmahal<span>5 Tours</span></h4>
                    </div>
                </div> <!-- single popular destination  end-->
            </div>
        </div>
    </section> <!-- end popular destination-->

    <section class="section-paddings best-services-area">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="section-title-version-2-black  text-center">
                        <h2>Why we are the best</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <!-- single we are best -->
                <div class="col-md-3 col-sm-6 col-xs-12 single-item">
                    <div class="single-best-services">
                        <div class="services-image">
                            <a href="#"><img src="<?php echo e(asset('')); ?>assets/web/images/icon/5-1.png" alt="">
                            </a>
                        </div>
                        <div class="services-content">
                            <a href="#"><h4>Travel Arrangements</h4></a>
                            <p>Lorem ipsum dolor sit ametpr consect adiu piscing eli sed diam nonum euismo.</p>
                            <a href="#">Read More <i class="fa fa-angle-right"></i></a>
                        </div>
                    </div>
                </div><!--End single we are best -->

                <div class="col-md-3  col-sm-6 col-xs-12  single-item">
                    <div class="single-best-services">
                        <div class="services-image">
                            <a href="#"><img src="<?php echo e(asset('')); ?>assets/web/images/icon/5-2.png" alt="">
                            </a>
                        </div>
                        <div class="services-content  single-item">
                            <a href="#"><h4>Best Price Guarantee</h4></a>
                            <p>Lorem ipsum dolor sit ametpr consect adiu piscing eli sed diam nonum euismo.</p>
                            <a href="#">Read More <i class="fa fa-angle-right"></i></a>
                        </div>
                    </div>
                </div><!--End single we are best -->

                <div class="col-md-3 col-sm-6 col-xs-12 single-item">
                    <div class="single-best-services">
                        <div class="services-image">
                            <a href="#"><img src="<?php echo e(asset('')); ?>assets/web/images/icon/5-3.png" alt="">
                            </a>
                        </div>
                        <div class="services-content">
                            <a href="#"><h4>BHappy Clients</h4></a>
                            <p>Lorem ipsum dolor sit ametpr consect adiu piscing eli sed diam nonum euismo.</p>
                            <a href="#">Read More <i class="fa fa-angle-right"></i></a>
                        </div>
                    </div>
                </div><!--End single we are best -->

                <div class="col-md-3 col-sm-6 col-xs-12 single-item">
                    <div class="single-best-services">
                        <div class="services-image">
                            <a href="#"><img src="<?php echo e(asset('')); ?>assets/web/images/icon/5-4.png" alt="">
                            </a>
                        </div>
                        <div class="services-content">
                            <a href="#"><h4>Travel Insurance</h4></a>
                            <p>Lorem ipsum dolor sit ametpr consect adiu piscing eli sed diam nonum euismo.</p>
                            <a href="#">Read More <i class="fa fa-angle-right"></i></a>
                        </div>
                    </div>
                </div><!--End single we are best -->
            </div>
        </div>
    </section>
<?php echo $__env->make('web.component.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- testimonial area start here -->
    <section class="testimonial-area image-bg-padding-100">
        <div class="testimonial-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="section-title-white text-center mbt-100">
                            <h2>What travellers Say About Us</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="custom-width text-center">
                        <!-- start top media -->
                        <div class="top-testimonial-image row slick-pagination">
                            <div class="carousel-images slider-nav">
                                <div>
                                    <img src="<?php echo e(asset('')); ?>assets/web/images/client/1.jpg" alt="1" class="img-circle">
                                </div>
                                <div>
                                    <img src="<?php echo e(asset('')); ?>assets/web/images/client/2.jpg" alt="3" class="img-circle">
                                </div>
                                <div>
                                    <img src="<?php echo e(asset('')); ?>assets/web/images/client/3.jpg" alt="2" class="img-circle">
                                </div>

                                <div>
                                    <img src="<?php echo e(asset('')); ?>assets/web/images/client/2.jpg" alt="2" class="img-circle">
                                </div>
                                <div>
                                    <img src="<?php echo e(asset('')); ?>assets/web/images/client/6.jpg" alt="2" class="img-circle">
                                </div>
                            </div>
                        </div>
                    </div><!-- end top media images -->

                    <div class="block-text row">
                        <div class="carousel-text slider-for col-sm-8 col-sm-offset-2">
                            <div class="testimonial-message">
                                <div class="message">
                                    <p>Lorem ipsum dolor sit amet, consecteituer adipiscing eluit, sed diapm nonummy nibhu euismod tincidunt ut laoreet dolor you magna aliquam erat volutpat. Ut wisi enim adefra miniumyp veniam, quis nostrud exerci tation ullavolutpat.</p>
                                </div>
                                <div class="rating">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <div class="client-bio">
                                    <h4>Jhonthan Smith</h4>
                                    <span>London Trip Travelers</span>
                                </div>
                            </div> <!-- client testimonial end -->

                            <div class="testimonial-message">
                                <div class="message">
                                    <p>Lorem ipsum dolor sit amet, consecteituer adipiscing eluit, sed diapm nonummy nibhu euismod tincidunt ut laoreet dolor you magna aliquam erat volutpat. Ut wisi enim adefra miniumyp veniam, quis nostrud.</p>
                                </div>
                                <div class="rating">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <div class="client-bio">
                                    <h4>Daniel Baci</h4>
                                    <span>Thailand Trip Travelers</span>
                                </div>
                            </div> <!-- client testimonial end -->

                            <div class="testimonial-message">
                                <div class="message">
                                    <p>Lorem ipsum dolor sit amet, consecteituer adipiscing eluit, sed diapm nonummy nibhu euismod tincidunt ut laoreet dolor you magna aliquam erat volutpat. Ut wisi enim adefra miniumyp veniam, quis nostrud.</p>
                                </div>
                                <div class="rating">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <div class="client-bio">
                                    <h4>John Doe</h4>
                                    <span>USA Trip Travelers</span>
                                </div>
                            </div> <!-- client testimonial end -->

                            <div class="testimonial-message">
                                <div class="message">
                                    <p>Lorem ipsum dolor sit amet, consecteituer adipiscing eluit, sed diapm nonummy nibhu euismod tincidunt ut laoreet dolor you magna aliquam erat volutpat. Ut wisi enim adefra miniumyp veniam, quis nostrud.</p>
                                </div>
                                <div class="rating">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <div class="client-bio">
                                    <h4>Jhonthan Smith</h4>
                                    <span>London Trip Travelers</span>
                                </div>
                            </div>	<!-- client testimonial end -->

                            <div class="testimonial-message">
                                <div class="message">
                                    <p>Lorem ipsum dolor sit amet, consecteituer adipiscing eluit, sed diapm nonummy nibhu euismod tincidunt ut laoreet dolor you magna aliquam erat volutpat. Ut wisi enim adefra miniumyp veniam, quis nostrud.</p>
                                </div>
                                <div class="rating">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <div class="client-bio">
                                    <h4>Jhonthan Smith</h4>
                                    <span>London Trip Travelers</span>
                                </div>
                            </div> <!-- client testimonial end -->

                            <div class="testimonial-message">
                                <div class="message">
                                    <p>Lorem ipsum dolor sit amet, consecteituer adipiscing eluit, sed diapm nonummy nibhu euismod tincidunt ut laoreet dolor you magna aliquam erat volutpat. Ut wisi enim adefra miniumyp veniam, quis nostrud</p>
                                </div>
                                <div class="rating">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <div class="client-bio">
                                    <h4>Jhonthan Smith</h4>
                                    <span>London Trip Travelers</span>
                                </div>
                            </div> <!-- client testimonial end -->
                        </div> <!-- /.block-text -->
                    </div>
                </div>
            </div>
        </div>
    </section> <!-- testimonial area end here -->

    <section class="section-paddings">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="section-title-version-2-black text-center">
                        <h2>Gallery from Travelars</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum </p>
                    </div>
                </div>
            </div>
            <!-- gallery iteam start here -->
            <div class="grid-3">
                <div class="col-sm-12 col-md-6 grid-item">
                    <figure>
                        <img src="<?php echo e(asset('')); ?>assets/web/images/gallery/1.jpg" alt="">
                        <figcaption>
                            <a href="<?php echo e(asset('')); ?>assets/web/images/gallery/1.jpg"><i class="fa fa-pencil"></i></a>
                            <h4>Place <span>Eiffel Tower</span></h4>
                            <h4>Caption By: <span>Michel Jusi</span></h4>
                        </figcaption>
                    </figure>
                </div> <!-- end single gallery -->

                <div class="col-sm-6 col-md-3 grid-item">
                    <figure>
                        <img src="<?php echo e(asset('')); ?>assets/web/images/gallery/2.jpg" alt="">
                        <figcaption>
                            <a href="<?php echo e(asset('')); ?>assets/web/images/gallery/1.jpg"><i class="fa fa-pencil"></i></a>
                            <h4>Place <span>Eiffel Tower</span></h4>
                            <h4>Caption By: <span>Michel Jusi</span></h4>
                        </figcaption>
                    </figure>
                </div> <!-- end single gallery -->

                <div class="col-sm-6 col-md-3 grid-item">
                    <figure>
                        <img src="<?php echo e(asset('')); ?>assets/web/images/gallery/3.jpg" alt="">
                        <figcaption>
                            <a href="<?php echo e(asset('')); ?>assets/web/images/gallery/1.jpg"><i class="fa fa-pencil"></i></a>
                            <h4>Place <span>Eiffel Tower</span></h4>
                            <h4>Caption By: <span>Michel Jusi</span></h4>
                        </figcaption>
                    </figure>
                </div> <!-- end single gallery -->

                <div class="col-sm-6 col-md-3 grid-item">
                    <figure>
                        <img src="<?php echo e(asset('')); ?>assets/web/images/gallery/6.jpg" alt="">
                        <figcaption>
                            <a href="<?php echo e(asset('')); ?>assets/web/images/gallery/1.jpg"><i class="fa fa-pencil"></i></a>
                            <h4>Place <span>Eiffel Tower</span></h4>
                            <h4>Caption By: <span>Michel Jusi</span></h4>
                        </figcaption>
                    </figure>
                </div> <!-- end single gallery -->

                <div class="col-sm-6 col-md-3 grid-item">
                    <figure>
                        <img src="<?php echo e(asset('')); ?>assets/web/images/gallery/4.jpg" alt="">
                        <figcaption>
                            <a href="<?php echo e(asset('')); ?>assets/web/images/gallery/1.jpg"><i class="fa fa-pencil"></i></a>
                            <h4>Place <span>Eiffel Tower</span></h4>
                            <h4>Caption By: <span>Michel Jusi</span></h4>
                        </figcaption>
                    </figure>
                </div> <!--single gallery end -->

                <div class=" col-sm-6 col-md-3 grid-item">
                    <figure>
                        <img src="<?php echo e(asset('')); ?>assets/web/images/gallery/5.jpg" alt="">
                        <figcaption>
                            <a href="<?php echo e(asset('')); ?>assets/web/images/gallery/1.jpg"><i class="fa fa-pencil"></i></a>
                            <h4>Place <span>Eiffel Tower</span></h4>
                            <h4>Caption By: <span>Michel Jusi</span></h4>
                        </figcaption>
                    </figure>
                </div>
                <!--single gallery end -->
                <!--single gallery -->
                <div class="col-sm-6 col-md-3 grid-item">
                    <figure>
                        <img src="<?php echo e(asset('')); ?>assets/web/images/gallery/7.jpg" alt="">
                        <figcaption>
                            <a href="<?php echo e(asset('')); ?>assets/web/images/gallery/1.jpg"><i class="fa fa-pencil"></i></a>
                            <h4>Place <span>Eiffel Tower</span></h4>
                            <h4>Caption By: <span>Michel Jusi</span></h4>
                        </figcaption>
                    </figure>
                </div> <!--single gallery end -->

                <div class="col-sm-6 col-md-3 grid-item">
                    <figure>
                        <img src="<?php echo e(asset('')); ?>assets/web/images/gallery/8.jpg" alt="">
                        <figcaption>
                            <a href="<?php echo e(asset('')); ?>assets/web/images/gallery/1.jpg"><i class="fa fa-pencil"></i></a>
                            <h4>Place <span>Eiffel Tower</span></h4>
                            <h4>Caption By: <span>Michel Jusi</span></h4>
                        </figcaption>
                    </figure>
                </div> <!--single gallery end -->
            </div> <!-- gallery item end here -->
        </div>
    </section> <!-- gallery section end here -->

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp-8-1\htdocs\sawari\resources\views/web/pages/index.blade.php ENDPATH**/ ?>