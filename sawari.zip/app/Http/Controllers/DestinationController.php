<?php

namespace App\Http\Controllers;
use Intervention\Image\ImageManagerStatic as Image;
use App\Models\Destination;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

// namespace Intervention\Image\Facades;


class DestinationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $destinations = Destination::orderBy('ranking', 'ASC')->get();
        // dd($destinations);
        return view('admin.pages.destination.index',compact('destinations'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // dd(public_path());
        return view('admin.pages.destination.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //  dd($request->all());
        $data = $request->validate([
            'title' => 'required',
            'image' => 'required|image|max:2048', // max file size of 2MB
        ]);
        $image = $request->file('image');
        $imageName = time().'.'.$image->extension();

        $img = Image::make($image->path());
        $img->fit(300, 300); // resize the image to fit within 380x310 while preserving aspect ratio
        $img->encode('jpg', 80); // convert image to JPEG format with 80% quality and reduce file size to 80kb
        $img->save(base_path('/uploads/destinations/').$imageName);
        $data['image'] = $imageName;
        $lastDestination = Destination::orderByDesc('ranking')->first();
        if ($lastDestination) {
            $data['ranking'] = $lastDestination->ranking + 1;
        } else {
            $data['ranking'] = 1;
        }
        $destination = Destination::create($data);

if ( $destination) {
    return redirect()->route('destinations.index')->with('success', 'Destination created successfully.');
    # code...
}else{
    return back()->with('error', 'Destination creating showing error.');
}





    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Destination  $destination
     * @return \Illuminate\Http\Response
     */
    public function show(Destination $destination)
    {
        return view('admin.pages.destination.view',compact('destination'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Destination  $destination
     * @return \Illuminate\Http\Response
     */
    public function edit(Destination $destination)
    {
        return view('admin.pages.destination.edit',compact('destination'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Destination  $destination
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Destination $destination)
    {



        $data = $request->validate([
            'title' => 'required',
            'ranking' => 'required',
        ]);

        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imageName = time().'.'.$image->extension();

            $img = Image::make($image->path());
            $img->fit(300, 300); // resize the image to fit within 380x310 while preserving aspect ratio
            $img->encode('jpg', 80); // convert image to JPEG format with 80% quality and reduce file size to 80kb
            $img->save(base_path('/uploads/destinations/').$imageName);

            $data['image'] = $imageName;
        }

        $destination = $destination->update($data);

        if ( $destination) {
            return redirect()->route('destinations.index')->with('success', 'Destination Updated successfully.');
            # code...
        }else{
            return back()->with('error', 'Destination Update showing error.');
        }

    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Destination  $destination
     * @return \Illuminate\Http\Response
     */
    public function destroy(Destination $destination)
    {
        // delete the destination's image file, if it exists

        if ($destination->image && file_exists(asset('uploads/destinations/'.$destination->image))) {
            unlink(asset('uploads/destinations/'.$destination->image));
        }

        // delete the destination from the database
        $destination->delete();

        return redirect()->route('destinations.index')->with('success', 'Destination deleted successfully.');
    }



     /**
     * Active the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Destination  $destination
     * @return \Illuminate\Http\Response
     */
    public function Active(Destination $destination)
    {

        $destination->status = '1';
        if ($destination->save()) {
            return redirect()->route('destinations.index')->with('success', 'destination Activated successfully.');
        } else {
            return back()->with('error', 'destination Activation Unsuccessfull');
        }
    }
    /**
     * Inactive  the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Destination  $destination
     * @return \Illuminate\Http\Response
     */
    public function Inactive(Destination $destination)

    {
        // dd($destination->status);
        $destination->status = '0';
        if ($destination->save()) {
            return redirect()->route('destinations.index')->with('success', 'destination Deactivated successfully.');
        } else {
            return back()->with('error', 'destination Dactivation Unsuccessfull.');
        }
    }
}
