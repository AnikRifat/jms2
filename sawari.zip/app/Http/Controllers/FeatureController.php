<?php

namespace App\Http\Controllers;
use Intervention\Image\ImageManagerStatic as Image;
use App\Models\Feature;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

// namespace Intervention\Image\Facades;


class FeatureController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $features = Feature::orderBy('id', 'DESC')->get();
        // dd($features);
        return view('admin.pages.feature.index',compact('features'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // dd(public_path());
        return view('admin.pages.feature.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //  dd($request->all());
        $data = $request->validate([
            'title' => 'required',
            'description' => 'required',
            'image' => 'required|image|max:2048', // max file size of 2MB
        ]);
        $image = $request->file('image');
        $imageName = time().'.'.$image->extension();

        $img = Image::make($image->path());
        $img->fit(80, 80); // resize the image to fit within 380x310 while preserving aspect ratio
        $img->encode('jpg', 80); // convert image to JPEG format with 80% quality and reduce file size to 80kb
        $img->save(base_path('/uploads/features/').$imageName);
        $data['image'] = $imageName;
        $lastFeature = Feature::orderByDesc('ranking')->first();
        if ($lastFeature) {
            $data['ranking'] = $lastFeature->ranking + 1;
        } else {
            $data['ranking'] = 1;
        }
        $feature = Feature::create($data);

if ( $feature) {
    return redirect()->route('features.index')->with('success', 'Feature created successfully.');
    # code...
}else{
    return back()->with('error', 'Feature creating showing error.');
}





    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Feature  $feature
     * @return \Illuminate\Http\Response
     */
    public function show(Feature $feature)
    {
        return view('admin.pages.feature.view',compact('feature'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Feature  $feature
     * @return \Illuminate\Http\Response
     */
    public function edit(Feature $feature)
    {
        return view('admin.pages.feature.edit',compact('feature'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Feature  $feature
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Feature $feature)
    {
        $data = $request->validate([
            'title' => 'required',
            'description' => 'required',

        ]);

        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imageName = time().'.'.$image->extension();

            $img = Image::make($image->path());
            $img->fit(80, 80); // resize the image to fit within 380x310 while preserving aspect ratio
            $img->encode('jpg', 80); // convert image to JPEG format with 80% quality and reduce file size to 80kb
            $img->save(base_path('/uploads/features/').$imageName);

            $data['image'] = $imageName;
        }

        $feature = $feature->update($data);



        if ( $feature) {
            return redirect()->route('features.index')->with('success', 'Feature Updated successfully.');
            # code...
        }else{
            return back()->with('error', 'Feature Update showing error.');
        }

    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Feature  $feature
     * @return \Illuminate\Http\Response
     */
    public function destroy(Feature $feature)
    {
        // delete the feature's image file, if it exists

        if ($feature->image && file_exists(asset('uploads/features/'.$feature->image))) {
            unlink(asset('uploads/features/'.$feature->image));
        }

        // delete the feature from the database
        $feature->delete();

        return redirect()->route('features.index')->with('success', 'Feature deleted successfully.');
    }



     /**
     * Active the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Feature  $feature
     * @return \Illuminate\Http\Response
     */
    public function Active(Feature $feature)
    {

        $feature->status = '1';
        if ($feature->save()) {
            return redirect()->route('features.index')->with('success', 'feature Activated successfully.');
        } else {
            return back()->with('error', 'feature Activation Unsuccessfull');
        }
    }
    /**
     * Inactive  the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Feature  $feature
     * @return \Illuminate\Http\Response
     */
    public function Inactive(Feature $feature)

    {
        // dd($feature->status);
        $feature->status = '0';
        if ($feature->save()) {
            return redirect()->route('features.index')->with('success', 'feature Deactivated successfully.');
        } else {
            return back()->with('error', 'feature Dactivation Unsuccessfull.');
        }
    }
}
