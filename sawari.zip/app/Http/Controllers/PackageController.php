<?php

namespace App\Http\Controllers;

use App\Models\Destination;
use Intervention\Image\ImageManagerStatic as Image;
use App\Models\Package;
use App\Models\Service;
use Illuminate\Http\Request;

// namespace Intervention\Image\Facades;

class PackageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $packages = Package::orderBy('id', 'DESC')->get();

        //  dd($packages);
        return view('admin.pages.package.index', compact('packages'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $services = Service::orderBy('id', 'DESC')->get();
        $destinations = Destination::orderBy('id', 'DESC')->get();
        return view('admin.pages.package.create', compact('services', 'destinations'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => 'required|string|max:255',
            'subtitle' => 'required|string|max:255',
            'description' => 'required|string',
            'itinerary' => 'required|string',
            'notes_policy' => 'required|string',
            'packages_pricing' => 'required|string',
            'price' => 'required|numeric',
            'destination_id' => 'required',
            'duration' => 'required|string|max:255',
            'check_in' => 'required|date',
            'check_out' => 'required|date',
            'tour_map' => 'required|string',
            'image' => 'required|image|max:2048',
            'service_id' => 'required|string|max:255',
        ]);

        $image = $request->file('image');
        $imageName = time() . '.' . $image->extension();

        $img = Image::make($image->path());
        $img->fit(380, 310); // resize the image to fit within 380x310 while preserving aspect ratio
        $img->encode('jpg', 80); // convert image to JPEG format with 80% quality and reduce file size to 80kb
        $img->save(base_path('/uploads/packages/') . $imageName);
        // Set package ranking
        $lastPackage = Package::orderByDesc('ranking')->first();
        if ($lastPackage) {
            $data['ranking'] = $lastPackage->ranking + 1;
        } else {
            $data['ranking'] = 1;
        }

        $data['image'] = $imageName;

        $package = Package::create($data);



        if ($package) {
            return redirect()
                ->route('packages.index')
                ->with('success', 'Package created successfully.');
            # code...
        } else {
            return back()->with('error', 'Package creating showing error.');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Package  $package
     * @return \Illuminate\Http\Response
     */
    public function show(Package $package)
    {
        return view('admin.pages.package.view', compact('package'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Package  $package
     * @return \Illuminate\Http\Response
     */
    public function edit(Package $package)
    {
        $services = Service::orderBy('id', 'DESC')->get();
        $destinations = Destination::orderBy('id', 'DESC')->get();

        return view('admin.pages.package.edit', compact('package', 'services', 'destinations'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Package  $package
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Package $package)
    {
        // dd($request->all());
        $data = $request->validate([
            'title' => 'required|string|max:255',
            'subtitle' => 'required|string|max:255',
            'description' => 'required|string',
            'itinerary' => 'required|string',
            'notes_policy' => 'required|string',
            'packages_pricing' => 'required|string',
            'price' => 'required|numeric',
            'destination_id' => 'required',
            'duration' => 'required|string|max:255',
            'check_in' => 'required|date',
            'check_out' => 'required|date',
            'tour_map' => 'required|string',
            'ranking' => 'required',
            'service_id' => 'required|string|max:255',
        ]);

        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imageName = time() . '.' . $image->extension();

            $img = Image::make($image->path());
            $img->fit(380, 310); // resize the image to fit within 380x310 while preserving aspect ratio
            $img->encode('jpg', 80); // convert image to JPEG format with 80% quality and reduce file size to 80kb
            $img->save(base_path('/uploads/packages/') . $imageName);

            $data['image'] = $imageName;
        }

        $package = $package->update($data);

        if ($package) {
            return redirect()
                ->route('packages.index')
                ->with('success', 'Package Updated successfully.');
            # code...
        } else {
            return back()->with('error', 'Package Update showing error.');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Package  $package
     * @return \Illuminate\Http\Response
     */
    public function destroy(Package $package)
    {
        // delete the package's image file, if it exists

        if ($package->image && file_exists(asset('uploads/packages/' . $package->image))) {
            unlink(asset('uploads/packages/' . $package->image));
        }

        // delete the package from the database
        $package->delete();

        return redirect()
            ->route('packages.index')
            ->with('success', 'Package deleted successfully.');
    }

    /**
     * Active the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Package  $package
     * @return \Illuminate\Http\Response
     */
    public function Active(Package $package)
    {
        $package->status = '1';
        if ($package->save()) {
            return redirect()
                ->route('packages.index')
                ->with('success', 'package Activated successfully.');
        } else {
            return back()->with('error', 'package Activation Unsuccessfull');
        }
    }
    /**
     * Inactive  the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Package  $package
     * @return \Illuminate\Http\Response
     */
    public function Inactive(Package $package)
    {
        $package->status = '0';
        if ($package->save()) {
            return redirect()
                ->route('packages.index')
                ->with('success', 'package Deactivated successfully.');
        } else {
            return back()->with('error', 'package Dactivation Unsuccessfull.');
        }
    }
}
