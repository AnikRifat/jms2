<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use App\Models\Content;
use App\Models\Destination;
use App\Models\Feature;
use App\Models\Hero;
use App\Models\Package;
use App\Models\Photo;
use App\Models\Service;
use App\Models\Testimonial;

class PublicController extends Controller
{
    public function index()
    {
        // $packages = Package::where('status', '1')->orderBy('id', 'DESC')->get();
        $hero = Hero::where('status', '1')->orderBy('id', 'DESC')->get();
        $blogs = Blog::where('status', '1')->orderBy('id', 'DESC')->get();
        $photos = Photo::where('status', '1')->orderBy('id', 'DESC')->get();
        $testimonials = Testimonial::where('status', '1')->orderBy('id', 'DESC')->get();
        $features = Feature::where('status', '1')->orderBy('id', 'DESC')->get();
        $content = Content::find(1);
        // $service s= $service->packages;
        // dd($service)s;
        // dd($blogs);
        return view('web.pages.index', compact( 'hero', 'content', 'blogs','testimonials','photos','features'));
    }


    public function about()
    {
        $hero = Hero::where('status', '1')->orderBy('id', 'DESC')->get();
        $content = Content::find(1);
        // $service s= $service->packages;
        // dd($service)s;
        return view('web.pages.about', compact( 'hero', 'content'));
    }


    public function dashboard()
    {
        return view('admin.pages.index');
    }
public function packageService($title){
        // dd($title);
        $service = Service::where('title', $title)->first();
        //  dd($service);
        return view('web.pages.packages', compact('service'));
}
    public function packages()
    {
        // dd($title);
        $packages = Package::where('status', '1')->orderBy('id', 'DESC')->get();
        $services = Service::where('status', '1')->orderBy('id', 'DESC')->get();
        //  dd($package);
        return view('web.pages.package.index', compact('packages','services'));
    }
    public function packageDetails($title)
    {
        // dd($title);
        $package = Package::where('title', $title)->first();
        $content = Content::find(1);
        //  dd($package);
        return view('web.pages.package.details', compact('package', 'content'));
    }

    public function blogs()
    {
        // dd($title);
        $blogs = Blog::where('status', '1')->orderBy('id', 'DESC')->get();
        //  dd($blog);
        return view('web.pages.blog.index', compact('blogs'));
    }
    public function blogDetails($title)
    {
        // dd($title);
        $blog = Blog::where('title', $title)->first();
        // dd($blog);
        $content = Content::find(1);
        //  dd($blog);
        return view('web.pages.blog.details', compact('blog', 'content'));
    }

public function contact(){
    return view('web.pages.contact');
}
}
