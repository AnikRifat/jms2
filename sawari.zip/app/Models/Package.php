<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Package extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'subtitle',
        'description',
        'itinerary',
        'notes_policy',
        'packages_pricing',
        'price',
        'destination_id',
        'duration',
        'check_in',
        'check_out',
        'tour_map',
        'image',
        'service_id',
        'ranking',
        'status',

    ];

    /**
     * Get the user who created the package.
     */
    public function service()
    {
        return $this->belongsTo(Service::class);
    }
    public function destination()
    {
        return $this->belongsTo(Destination::class);
    }
}

