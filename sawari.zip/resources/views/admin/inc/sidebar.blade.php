<div id="sidebar-menu">
    <!-- Left Menu Start -->
    <ul class="metismenu list-unstyled" id="side-menu">
        <li class="menu-title" key="t-menu">Menu</li>

        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="bx bx-home-circle"></i>
                <span key="t-dashboards">Contacts</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="{{ route('package-queries.index') }}" key="t-default">Package Querry</a></li>

            </ul>
        </li>

        <li class="menu-title" key="t-menu">Web Contents</li>
        {{-- package --}}
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="bx bx-home-circle"></i>
                <span key="t-package">Package</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="{{ route('packages.index') }}" key="t-list">All Packages</a></li>
                <li><a href="{{ route('packages.create') }}" key="t-create">Create Packages</a></li>

            </ul>
        </li>
        {{-- End - package --}}
        {{-- service --}}
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="bx bx-home-circle"></i>
                <span key="t-service">Service</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="{{ route('services.index') }}" key="t-list">All Service</a></li>
                <li><a href="{{ route('services.create') }}" key="t-create">Create Service</a></li>

            </ul>
        </li>
        {{-- End - service --}}


   {{-- photo --}}
   <li>
    <a href="javascript: void(0);" class="has-arrow waves-effect">
        <i class="bx bx-home-circle"></i>
        <span key="t-photo">Gallery</span>
    </a>
    <ul class="sub-menu" aria-expanded="false">
        <li><a href="{{ route('photos.index') }}" key="t-list">All Photo</a></li>
        <li><a href="{{ route('photos.create') }}" key="t-create">Add Photo</a></li>

    </ul>
</li>
{{-- End - photo --}}

         {{-- destination --}}
         <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="bx bx-home-circle"></i>
                <span key="t-destination">Destination</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="{{ route('destinations.index') }}" key="t-list">All Destination</a></li>
                <li><a href="{{ route('destinations.create') }}" key="t-create">Create Destination</a></li>

            </ul>
        </li>
        {{-- End - destination --}}
                 {{-- feature --}}
                 <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-home-circle"></i>
                        <span key="t-feature">Feature</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="{{ route('features.index') }}" key="t-list">All Feature</a></li>
                        <li><a href="{{ route('features.create') }}" key="t-create">Create Feature</a></li>

                    </ul>
                </li>
                {{-- End - feature --}}
         {{-- testimonial --}}
         <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="bx bx-home-circle"></i>
                <span key="t-testimonial">Testimonial</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="{{ route('testimonials.index') }}" key="t-list">All Testimonial</a></li>
                <li><a href="{{ route('testimonials.create') }}" key="t-create">Create Testimonial</a></li>

            </ul>
        </li>
        {{-- End - testimonial --}}
        {{-- start - blog --}}
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="bx bx-home-circle"></i>
                <span key="t-blog">Blog</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="{{ route('blogs.index') }}" key="t-list">All Blog</a></li>
                <li><a href="{{ route('blogs.create') }}" key="t-create">Create Blog</a></li>

            </ul>
        </li>
        {{-- End - blog --}}
        {{-- hero --}}
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="bx bx-home-circle"></i>
                <span key="t-hero">Hero</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="{{ route('hero.index') }}" key="t-list">All Hero</a></li>
                <li><a href="{{ route('hero.create') }}" key="t-create">Create Hero</a></li>

            </ul>

        </li>
        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="bx bx-home-circle"></i>
                <span key="t-hero">Website Content</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="{{ route('about.edit',1) }}" key="t-list">About Us</a></li>
                <li><a href="{{ route('contact.edit',1) }}" key="t-list">Contact Info</a></li>
                <li><a href="{{ route('general.edit',1) }}" key="t-list">General Setting</a></li>

            </ul>

        </li>
        {{-- End - hero --}}
    </ul>
</div>
