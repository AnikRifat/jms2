<section class="section-paddings best-services-area">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="section-title-version-2-black  text-center">
                    <h2>Why we are the best</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum
                    </p>
                </div>
            </div>
        </div>


        <div class="partner-slider-2">

@foreach ($features as $feature)
<div class="m-4">
    <div class="single-best-services">
        <div class="services-image">
            <a href="#"><img src="{{ asset('uploads/features/' . $feature->image) }}" alt="">
            </a>
        </div>
        <div class="services-content">
            <a href="#">
                <h4>{{ $feature->title }}</h4>
            </a>
            <p>{{ $feature->description }}</p>
        </div>
    </div>
</div>
@endforeach


        </div>


    </div>
</section>
