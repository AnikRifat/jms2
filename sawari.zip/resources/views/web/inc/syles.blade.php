 <!-- Google Fonts -->
 <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
 <!-- Favicon -->
 <link rel="shortcut icon" type="image/x-icon" href="{{ asset('') }}assets/web/images/favicon.ico">
 <!-- bootstrap css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/css/bootstrap.min.css">

 <!-- animate css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/css/animate.css">
 <!-- Button Hover animate css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/css/hover-min.css">
 <!-- jquery-ui.min css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/css/jquery-ui.min.css">
 <!-- meanmenu css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/css/meanmenu.min.css">
 <!-- owl.carousel css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/css/owl.carousel.min.css">
 <!-- slick css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/css/slick.css">
 <!-- chosen.min-->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/css/chosen.min.css">
 <!-- chosen.min-->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/css/jquery-customselect.css">
 <!-- font-awesome css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/css/font-awesome.min.css">
 <!-- magnific Css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/css/magnific-popup.css">
 <!-- Revolution Slider -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/css/assets/revolution/layers.css">
 <link rel="stylesheet" href="{{ asset('') }}assets/web/css/assets/revolution/navigation.css">
 <link rel="stylesheet" href="{{ asset('') }}assets/web/css/assets/revolution/settings.css">

 <link rel="stylesheet" href="https://unpkg.com/flexmasonry/dist/flexmasonry.css">
 <!-- custome css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/css/style.css">
 <!-- responsive css -->
 <link rel="stylesheet" href="{{ asset('') }}assets/web/css/responsive.css">

