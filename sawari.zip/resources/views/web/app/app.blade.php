<!DOCTYPE html>
<html class="no-js" lang="zxx">
<head>
    @include('web.inc.head')
    @include('web.inc.syles')
</head>
<body>
<!-- Preloader -->
{{-- <div id="preloader">
    <div id="status">&nbsp;</div>
</div> --}}
 <!-- header area end here -->
@include('web.inc.header')
<!-- slider area start here -->
@yield('main-body')
@include('web.inc.footer')
    <!-- ============================
    		JavaScript Files
    ============================= -->
@include('web.inc.script')
@yield('script')
</body>


</html>
