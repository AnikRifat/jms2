<?php

use App\Http\Controllers\BlogController;
use App\Http\Controllers\ContentController;
use App\Http\Controllers\DestinationController;
use App\Http\Controllers\FeatureController;
use App\Http\Controllers\HeroController;
use App\Http\Controllers\PackageController;
use App\Http\Controllers\PackageQuerryController;
use App\Http\Controllers\PhotoController;
use App\Http\Controllers\PublicController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\TestimonialController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [PublicController::class, 'index'])->name('index');
Route::get('/about', [PublicController::class, 'about'])->name('about');
Route::get('/contact', [PublicController::class, 'contact'])->name('contact');
Route::get('/{service}/package', [PublicController::class, 'packageService'])->name('service.package');
Route::get('/package/{package}', [PublicController::class, 'packageDetails'])->name('package.details');
Route::get('/blog/{blog}', [PublicController::class, 'blogDetails'])->name('blog.details');
Route::get('/blogs', [PublicController::class, 'blogs'])->name('blogs.all');
Route::get('/all-packages', [PublicController::class, 'packages'])->name('packages.all');


Route::post('/package-query', [PackageQuerryController::class, 'store'])->name('package-query.store');


Route::prefix('/dashboard')->middleware('auth')->group(function () {
    Route::get('/', [PublicController::class, 'dashboard'])->name('dashboard.index');
    Route::get('/package-queries', [PackageQuerryController::class, 'index'])->name('package-queries.index');

    Route::prefix('packages')->group(function () {
        // Package-Routes
        Route::get('/', [PackageController::class, 'index'])->name('packages.index');
        Route::get('/create', [PackageController::class, 'create'])->name('packages.create');
        Route::post('/', [PackageController::class, 'store'])->name('packages.store');
        Route::get('/{package}', [PackageController::class, 'show'])->name('packages.show');
        Route::get('/{package}/edit', [PackageController::class, 'edit'])->name('packages.edit');
        Route::put('/{package}', [PackageController::class, 'update'])->name('packages.update');
        Route::get('/{package}', [PackageController::class, 'destroy'])->name('packages.destroy');
        Route::get('/active/{package}', [PackageController::class, 'active'])->name('packages.active');
        Route::get('/inactive/{package}', [PackageController::class, 'inactive'])->name('packages.inactive');
    });


    Route::prefix('services')->group(function () {
        // Hero-Routes
        Route::get('/', [ServiceController::class, 'index'])->name('services.index');
        Route::get('/create', [ServiceController::class, 'create'])->name('services.create');
        Route::post('/', [ServiceController::class, 'store'])->name('services.store');
        Route::get('/{service}', [ServiceController::class, 'show'])->name('services.show');
        Route::get('/{service}/edit', [ServiceController::class, 'edit'])->name('services.edit');
        Route::put('/{service}', [ServiceController::class, 'update'])->name('services.update');
        Route::get('/{service}', [ServiceController::class, 'destroy'])->name('services.destroy');
        Route::get('/active/{service}', [ServiceController::class, 'active'])->name('services.active');
        Route::get('/inactive/{service}', [ServiceController::class, 'inactive'])->name('services.inactive');
    });

    Route::prefix('photos')->group(function () {
        // Hero-Routes
        Route::get('/', [PhotoController::class, 'index'])->name('photos.index');
        Route::get('/create', [PhotoController::class, 'create'])->name('photos.create');
        Route::post('/', [PhotoController::class, 'store'])->name('photos.store');
        Route::get('/{photo}', [PhotoController::class, 'show'])->name('photos.show');
        Route::get('/{photo}/edit', [PhotoController::class, 'edit'])->name('photos.edit');
        Route::put('/{photo}', [PhotoController::class, 'update'])->name('photos.update');
        Route::get('/{photo}', [PhotoController::class, 'destroy'])->name('photos.destroy');
        Route::get('/active/{photo}', [PhotoController::class, 'active'])->name('photos.active');
        Route::get('/inactive/{photo}', [PhotoController::class, 'inactive'])->name('photos.inactive');
    });



    Route::prefix('destinations')->group(function () {
        // Hero-Routes
        Route::get('/', [DestinationController::class, 'index'])->name('destinations.index');
        Route::get('/create', [DestinationController::class, 'create'])->name('destinations.create');
        Route::post('/', [DestinationController::class, 'store'])->name('destinations.store');
        Route::get('/{destination}', [DestinationController::class, 'show'])->name('destinations.show');
        Route::get('/{destination}/edit', [DestinationController::class, 'edit'])->name('destinations.edit');
        Route::put('/{destination}', [DestinationController::class, 'update'])->name('destinations.update');
        Route::get('/{destination}', [DestinationController::class, 'destroy'])->name('destinations.destroy');
        Route::get('/active/{destination}', [DestinationController::class, 'active'])->name('destinations.active');
        Route::get('/inactive/{destination}', [DestinationController::class, 'inactive'])->name('destinations.inactive');
    });


    Route::prefix('blogs')->group(function () {
        // Blog-Routes
        Route::get('/', [BlogController::class, 'index'])->name('blogs.index');
        Route::get('/create', [BlogController::class, 'create'])->name('blogs.create');
        Route::post('/', [BlogController::class, 'store'])->name('blogs.store');
        Route::get('/{blog}', [BlogController::class, 'show'])->name('blogs.show');
        Route::get('/{blog}/edit', [BlogController::class, 'edit'])->name('blogs.edit');
        Route::put('/{blog}', [BlogController::class, 'update'])->name('blogs.update');
        Route::get('/{blog}', [BlogController::class, 'destroy'])->name('blogs.destroy');
        Route::get('/active/{blog}', [BlogController::class, 'active'])->name('blogs.active');
        Route::get('/inactive/{blog}', [BlogController::class, 'inactive'])->name('blogs.inactive');
    });



    Route::prefix('features')->group(function () {
        // Blog-Routes
        Route::get('/', [FeatureController::class, 'index'])->name('features.index');
        Route::get('/create', [FeatureController::class, 'create'])->name('features.create');
        Route::post('/', [FeatureController::class, 'store'])->name('features.store');
        Route::get('/{feature}', [FeatureController::class, 'show'])->name('features.show');
        Route::get('/{feature}/edit', [FeatureController::class, 'edit'])->name('features.edit');
        Route::put('/{feature}', [FeatureController::class, 'update'])->name('features.update');
        Route::get('/{feature}', [FeatureController::class, 'destroy'])->name('features.destroy');
        Route::get('/active/{feature}', [FeatureController::class, 'active'])->name('features.active');
        Route::get('/inactive/{feature}', [FeatureController::class, 'inactive'])->name('features.inactive');
    });


    Route::prefix('testimonials')->group(function () {
        // Blog-Routes
        Route::get('/', [TestimonialController::class, 'index'])->name('testimonials.index');
        Route::get('/create', [TestimonialController::class, 'create'])->name('testimonials.create');
        Route::post('/', [TestimonialController::class, 'store'])->name('testimonials.store');
        Route::get('/{testimonial}', [TestimonialController::class, 'show'])->name('testimonials.show');
        Route::get('/{testimonial}/edit', [TestimonialController::class, 'edit'])->name('testimonials.edit');
        Route::put('/{testimonial}', [TestimonialController::class, 'update'])->name('testimonials.update');
        Route::get('/{testimonial}', [TestimonialController::class, 'destroy'])->name('testimonials.destroy');
        Route::get('/active/{testimonial}', [TestimonialController::class, 'active'])->name('testimonials.active');
        Route::get('/inactive/{testimonial}', [TestimonialController::class, 'inactive'])->name('testimonials.inactive');
    });



    Route::prefix('hero')->group(function () {
        // Hero-Routes
        Route::get('/', [HeroController::class, 'index'])->name('hero.index');
        Route::get('/create', [HeroController::class, 'create'])->name('hero.create');
        Route::post('/', [HeroController::class, 'store'])->name('hero.store');
        Route::get('/{hero}', [HeroController::class, 'show'])->name('hero.show');
        Route::get('/{hero}/edit', [HeroController::class, 'edit'])->name('hero.edit');
        Route::put('/{hero}', [HeroController::class, 'update'])->name('hero.update');
        Route::get('/{hero}', [HeroController::class, 'destroy'])->name('hero.destroy');
        Route::get('/active/{hero}', [HeroController::class, 'active'])->name('hero.active');
        Route::get('/inactive/{hero}', [HeroController::class, 'inactive'])->name('hero.inactive');
    });


    Route::prefix('content')->group(function () {
        // Hero-Routes
        Route::get('/about/{content}/edit', [ContentController::class, 'editAbout'])->name('about.edit');
        Route::put('/about/{content}', [ContentController::class, 'updateAbout'])->name('about.update');

        Route::get('/general/{content}/edit', [ContentController::class, 'editGeneral'])->name('general.edit');
        Route::put('/general/{content}', [ContentController::class, 'updateGeneral'])->name('general.update');
        Route::get('/contact/{content}/edit', [ContentController::class, 'editContact'])->name('contact.edit');
        Route::put('/contact/{content}', [ContentController::class, 'updateContact'])->name('contact.update');
    });





});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
